namespace OptimizerApi.Models;

// نام خاصیت‌ها عمداً camelCase و هم‌نام دقیق فیلدهای جاوااسکریپت برنامه است — تا فاز ۳
// (وصل‌کردن فرانت‌اند) بدون نگاشت/تغییر ساختار دیتا در کد HTML ممکن باشد.

public class Material
{
    public string id { get; set; } = "";
    public string kind { get; set; } = "";
    public string? category { get; set; }
    public string name { get; set; } = "";
    public string? refFormType { get; set; }
    public decimal? sheetLen { get; set; }
    public decimal? sheetWidth { get; set; }
    public decimal? grammage { get; set; }
    public decimal? weightPerSheet { get; set; }
    public int? packQty { get; set; }
    public decimal? pricePerPack { get; set; }
    public decimal? pricePerKg { get; set; }
    public int? creditLTMonths { get; set; }
    public decimal? creditSurchargePctPerMonth { get; set; }
    public decimal? inventoryKg { get; set; }
    public int? leadTimeMonths { get; set; }
}

public class Product
{
    public string id { get; set; } = "";
    public string? code { get; set; }
    public string name { get; set; } = "";
    public string? publisher { get; set; }
    public string? basket { get; set; }
    public string trim { get; set; } = "";
    public int? pages { get; set; }
    public int? colorCount { get; set; }
    public decimal? marginPct { get; set; }
    public decimal? marginAmt { get; set; }
    public decimal? budgetUnitCost { get; set; }
    public DateOnly? pdfReady { get; set; }
    public decimal? forecast { get; set; }
    public decimal? inventory { get; set; }
    public int? stockPolicy { get; set; }
    public decimal? maxBatch { get; set; }
    public decimal? salePrice { get; set; }
    public string? materialId { get; set; }
    public string? hasLatFee { get; set; }
    public bool? forecastAuto { get; set; }
    public decimal? maxShelfLifeYears { get; set; }
    public decimal? royaltyPct { get; set; }
}

public class FormLine
{
    public int id { get; set; }
    public string formType { get; set; } = "";
    public decimal rate { get; set; }
    public int? pagesPerForm { get; set; }
    public int? a4InForm { get; set; }
    public int? colorCount { get; set; }
    public decimal? coefficient { get; set; }
    public int? minRunSheets { get; set; }
    public decimal? pricePerColorBase { get; set; }
    public decimal? monthlyCapA4 { get; set; }
    public decimal? pricePerColor { get; set; }
    public int? coversPerForm { get; set; }
    public decimal? baseTirage { get; set; }
    public List<decimal>? monthlyCaps { get; set; }
}

public class LithoContractor
{
    public string id { get; set; } = "";
    public string? contractorCode { get; set; }
    public string name { get; set; } = "";
    public string tech { get; set; } = "";
    public string? trim { get; set; }
    public List<FormLine> formLines { get; set; } = new();
}

public class PrinterContractor
{
    public string id { get; set; } = "";
    public string? contractorCode { get; set; }
    public string printer { get; set; } = "";
    public string? machine { get; set; }
    public string tech { get; set; } = "";
    public int? colorCap { get; set; }
    public decimal? waste { get; set; }
    public decimal? scissorWidth { get; set; }
    public decimal? requiredCutoff { get; set; }
    public decimal? mazandaranSurchargePct { get; set; }
    public List<FormLine> formLines { get; set; } = new();
}

public class BinderyContractor
{
    public string id { get; set; } = "";
    public string? contractorCode { get; set; }
    public string name { get; set; } = "";
    public string? bindType { get; set; }
    public string? trim { get; set; }
    public List<FormLine> formLines { get; set; } = new();
}

public class CoverPrinterContractor
{
    public string id { get; set; } = "";
    public string? contractorCode { get; set; }
    public string name { get; set; } = "";
    public List<FormLine> formLines { get; set; } = new();
}

public class FormRow
{
    public int id { get; set; }
    public string tech { get; set; } = "";
    public string trim { get; set; } = "";
    public string? a4InForm { get; set; }
    public string? sheetType { get; set; }
    public string formType { get; set; } = "";
    public int pagesPerForm { get; set; }
}

public class PaperSpec
{
    public string id { get; set; } = "";
    public string materialId { get; set; } = "";
    public string trim { get; set; } = "";
    public string? dims { get; set; }
    public decimal? pageWeight { get; set; }
    public decimal? wastePct { get; set; }
    public decimal? grossConsumption { get; set; }
    public decimal? consumptionWithWaste { get; set; }
    public string? sheetType { get; set; }
    public int? pagesPerSheet { get; set; }
}

public class SettingItem
{
    public string settingKey { get; set; } = "";
    public string? settingValue { get; set; }
}
