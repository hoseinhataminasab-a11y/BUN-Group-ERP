# API فاز ۳ — ورود کاربران، جدول‌ها، ذخیرهٔ ورژن، سند مشترک، سرو خود برنامه

## اجرا
1. اسکریپت‌های SQL به ترتیب: `Phase3b_Patch.sql` (اگر قبلاً نزده‌اید) و `Phase3c_StateDocs.sql`
2. محتوای این zip را روی پوشهٔ قبلی کپی کنید (`appsettings.json` خودتان را نگه دارید)
3. برای اینکه از سیستم‌های دیگر هم قابل‌دسترس باشد: `dotnet run --urls http://0.0.0.0:5000`
   (و در فایروال ویندوز پورت 5000 را باز کنید)
4. کاربران آدرس `http://آی‌پی-این-سیستم:5000/` را در مرورگر باز می‌کنند (خود برنامه از `wwwroot/index.html` سرو می‌شود)
5. مستندات و تست: `/swagger`

## Endpointها
- `/api/auth/login | me | change-password`
- `/api/users` (admin)، `/api/roles`، `/api/roles/{id}/permissions`، `/api/audit` (admin)
- `/api/state/{key}` (GET/PUT با baseVersion)، `/api/state/{key}/version`، `/history`، `/restore/{id}`
- `/api/t` فهرست جدول‌ها، `/api/t/{table}` GET/POST/DELETE، `/api/t/{table}/{id}`، `/api/t/{table}/bulk?mode=replace|append`
- `/api/versions/{prodplan|salesplan|prodactual}` POST، `/api/versions?kind=&year=`، `/api/versions/{id}`، `/api/versions/{id}/rows`، `/api/versions/approved`، `/api/versions/{id}/approve`، `DELETE /api/versions/{id}`

## نسخهٔ ۲۷۱ (v271)
- `wwwroot/index.html` جدید (تب محصولات، BOM، مشخصات کاغذ، عرض خودکار ستون‌ها).
- فایل جدید `Endpoints/ExternalInventoryEndpoints.cs` و یک خط در `Program.cs` برای موجودی آنلاین مواد:
  - `GET /api/external/inventory/status`
  - `GET /api/external/inventory/columns?table=dbo.X`
  - `POST /api/external/inventory/pull`
- برای فعال‌شدن، در `appsettings.json` این بخش اضافه شود (با یک کاربر SQL **فقط‌خواندنی** روی راهکاران یا DW):
  ```json
  "ExternalInventory": { "ConnectionString": "Server=...;Database=...;User Id=...;Password=...;TrustServerCertificate=True;" }
  ```
  تا وقتی خالی است، برنامه عادی کار می‌کند و فقط این بخش «تنظیم نشده» نشان می‌دهد.
- تغییری در جدول‌های SQL لازم نیست؛ جدول‌های جدید (انواع قطع، فرم، کاغذ، تأمین‌کنندگان) داخل سند مشترک برنامه ذخیره می‌شوند.
