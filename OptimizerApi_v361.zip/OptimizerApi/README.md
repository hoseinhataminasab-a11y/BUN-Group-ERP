# OptimizerApi — فاز ۲ (لایهٔ API بین فرانت‌اند و SQL Server)

## این چیست
یک وب‌سرویس ASP.NET Core (Minimal API + Dapper) که مستقیم با `OptimizerDB` روی
`10.10.7.34` صحبت می‌کند و همان جدول‌هایی را می‌خواند/می‌نویسد که در فاز ۱ ساختید
و پر کردید (Materials, Products, LithoContractors/+FormLines, PrinterContractors/+FormLines,
BinderyContractors/+FormLines, CoverPrinterContractors/+FormLines, Forms, PaperSpecs, Settings).

نام خاصیت‌های JSON عمداً همان نام فیلدهای جاوااسکریپت برنامه است (مثلاً `salePrice`،
`materialId`، `formLines`) تا فاز ۳ (وصل‌کردن فایل HTML به این API) کمترین تغییر را
در کد فرانت‌اند لازم داشته باشد.

## اجرا روی سرور (همان 10.10.7.34)
پیش‌نیاز: .NET 8 SDK (یا فقط ASP.NET Core Runtime برای اجرا، SDK برای build/publish).
دانلود: https://dotnet.microsoft.com/download/dotnet/8.0

```powershell
cd OptimizerApi
dotnet restore
dotnet run
```
پیش‌فرض روی `http://localhost:5000` و `https://localhost:5001` بالا می‌آید و مستندات
Swagger در `/swagger` قابل مشاهده و تست است (مثلاً `http://10.10.7.34:5000/swagger`).

برای اجرای دائمی (نه فقط `dotnet run` در یک پنجرهٔ کنسول باز)، یکی از این دو راه:
1. **IIS** (اگر همین سرور IIS دارد): `dotnet publish -c Release -o C:\inetpub\OptimizerApi` و
   یک سایت IIS با ASP.NET Core Module به آن پوشه بسازید.
2. **Windows Service ساده**: `dotnet publish -c Release` و با `sc create` یا NSSM آن را
   به یک سرویس ویندوزی تبدیل کنید تا با ری‌استارت سرور هم بالا بیاید.

## تنظیمات مهم قبل از اجرای واقعی
- **رمز عبور**: `appsettings.json` فعلاً همان رمز موقتی که فرستادید را دارد. قبل از
  استفادهٔ واقعی/چندکاربره، این رمز را در SQL Server عوض کنید و اینجا هم به‌روزرسانی
  کنید (بهتر: به‌جای نوشتن رمز در فایل، از `dotnet user-secrets` یا متغیر محیطی
  `ConnectionStrings__Optimizer` استفاده کنید).
- **CORS**: فعلاً `AllowedOrigins: ["*"]` یعنی هر صفحه‌ای (از هر آدرسی) اجازه دارد به
  این API درخواست بزند — چون فایل HTML برنامه فعلاً از دیسک (`file://`) باز می‌شود.
  وقتی فایل HTML را هم روی همین سرور سرو کردید (پیشنهاد فاز ۳)، بهتر است این را به
  آدرس دقیق همان سرویس محدود کنید.

## نقشهٔ مسیرها (Endpoints)
| مسیر | متد | کاربرد |
|---|---|---|
| `/api/masterdata` | GET | کل Master Data یک‌جا — معادل بارگذاری اولیهٔ `state` در برنامهٔ فعلی |
| `/api/materials` | GET | لیست متریال‌ها |
| `/api/materials/{id}` | PUT / DELETE | ثبت/ویرایش (upsert) یا حذف یک متریال |
| `/api/products` | GET | لیست محصولات (۱٬۰۶۹ ردیف) |
| `/api/products/{id}` | PUT / DELETE | ثبت/ویرایش یا حذف یک محصول |
| `/api/litho`, `/api/printers`, `/api/binderies`, `/api/coverprinters` | GET | لیست پیمانکاران هر گروه، هرکدام با `formLines` تودرتو |
| همان مسیرها + `/{id}` | PUT / DELETE | ثبت/ویرایش کل پیمانکار به‌همراه تمام formLines اش (جایگزینی کامل formLines قبلی) یا حذف |
| `/api/forms` | GET / POST | لیست/افزودن ردیف مرجع فرم |
| `/api/forms/{id}` | DELETE | حذف یک ردیف فرم |
| `/api/paperspecs` | GET | لیست مشخصات کاغذ |
| `/api/paperspecs/{id}` | PUT / DELETE | ثبت/ویرایش یا حذف |
| `/api/settings` | GET | همهٔ تنظیمات به‌صورت آرایهٔ `{settingKey, settingValue}` |
| `/api/settings/{key}` | PUT | ویرایش یک تنظیم |

## چیزی که هنوز اینجا نیست (فاز بعد)
- خودِ فایل HTML هنوز به این API وصل نیست — هنوز از `localStorage` می‌خواند/می‌نویسد.
  فاز ۳: در فایل HTML، `window.storage.get/set` را با `fetch` به همین مسیرها جایگزین کنید.
- احراز هویت واقعی (الان API کاملاً باز است، هرکسی در شبکه بدون رمز می‌تواند بخواند/بنویسد).
  باید قبل از استفادهٔ واقعی چندکاربره یک لایهٔ ساده (مثلاً API Key یا JWT ساده، متصل به
  همان جدول `AppUsers`) اضافه شود.
- `PlanArchiveVersions/Rows` و `Actuals` (آرشیو برنامه‌ها و ثبت اکچوال) در شِمای فاز ۱
  ساخته شده‌اند ولی هنوز endpoint ندارند — چون هنوز به فرانت‌اند وصل نشده‌اند، اولویت
  پایین‌تری داشتند؛ در فاز ۳/۴ اضافه می‌شود.

## محدودیت این تحویل
این پروژه در محیط ابری من (که به شبکهٔ داخلی شما دسترسی ندارد و SDK دات‌نت هم روی آن
نصب نیست) build/run واقعی نشده — کد را با دقت خط‌به‌خط بازبینی کردم، ولی build واقعی
(`dotnet build`) را شما باید روی سرور خودتان انجام دهید. اگر خطای کامپایل یا اجرا
گرفتید، دقیقاً همان پیام را برایم بفرستید تا فوراً اصلاح کنم.
