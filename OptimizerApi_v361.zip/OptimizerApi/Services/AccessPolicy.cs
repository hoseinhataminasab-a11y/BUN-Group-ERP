using System.Text.Json;
using Dapper;
using OptimizerApi.Data;

namespace OptimizerApi.Services;

// اجرای دسترسی «ماژول» در خود سرور.
// منبع قوانین: همان تنظیمات «مدیریت دسترسی» برنامه (accessControl.modulePerms داخل سند اصلی برنامه).
// هر ماژول برای هر نقش یکی از سه حالت دارد: none (دیدن هم ممنوع) / read (فقط دیدن) / write (دیدن و تغییر).
// اگر برای یک نقش و ماژول قاعده‌ای ثبت نشده باشد، «write» فرض می‌شود (مثل خود برنامه). مدیر کل همیشه آزاد است.
// اگر خواندن قوانین به هر دلیل خطا بدهد، برای اینکه کار تولید متوقف نشود، آخرین قوانین سالم (یا آزاد) استفاده می‌شود.
// تب/پنجره/ستون/سطر همچنان در برنامه اعمال می‌شود؛ فقط سطح ماژول اینجا قطعی و غیرقابل‌دورزدن است.
public static class AccessPolicy
{
    private const string DocKey = "ban_or_state_v3";
    private static readonly TimeSpan Ttl = TimeSpan.FromSeconds(20);
    private static readonly object Lock = new();
    private static DateTime _loadedAt = DateTime.MinValue;
    private static Dictionary<string, string> _perms = new(StringComparer.OrdinalIgnoreCase); // "role|module" -> access

    // جدول‌های بخش فروش (باید با TableEndpoints هماهنگ بماند)
    private static readonly HashSet<string> SalesTables = new(StringComparer.OrdinalIgnoreCase)
    {
        "SfProducts", "Channels", "SalesHistory", "MarketHistory", "OwnDistributorSales", "DistributorReports",
        "RealDistributorSales", "MacroInflation", "MacroRegulatoryEvents", "MacroRiskFactors", "SfSettings"
    };

    public static string ModuleOfTable(string table) => SalesTables.Contains(table) ? "grp-sales" : "grp-master";

    public static string? ModuleOfVersionKind(string kind) => kind.ToLowerInvariant() switch
    {
        "prodplan" or "prodactual" => "grp-prod",
        "salesplan" => "grp-sales",
        _ => null
    };

    private static async Task Refresh(IServiceProvider sp)
    {
        if (DateTime.UtcNow - _loadedAt < Ttl) return;
        try
        {
            var db = sp.GetRequiredService<Db>();
            using var c = db.Open();
            var json = await c.QuerySingleOrDefaultAsync<string>("SELECT Json FROM AppStateDocs WHERE DocKey = @k", new { k = DocKey });
            var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (!string.IsNullOrEmpty(json))
            {
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("accessControl", out var ac)
                    && ac.ValueKind == JsonValueKind.Object
                    && ac.TryGetProperty("modulePerms", out var mp)
                    && mp.ValueKind == JsonValueKind.Array)
                {
                    foreach (var p in mp.EnumerateArray())
                    {
                        var r = p.TryGetProperty("roleId", out var rv) ? rv.GetString() : null;
                        var m = p.TryGetProperty("module", out var mv) ? mv.GetString() : null;
                        var a = p.TryGetProperty("access", out var av) ? av.GetString() : null;
                        if (r != null && m != null && a is "none" or "read" or "write") map[r + "|" + m] = a!;
                    }
                }
            }
            lock (Lock) { _perms = map; _loadedAt = DateTime.UtcNow; }
        }
        catch
        {
            // خطا در خواندن قوانین: قوانین قبلی می‌ماند و چند ثانیهٔ دیگر دوباره تلاش می‌شود.
            lock (Lock) { _loadedAt = DateTime.UtcNow - Ttl + TimeSpan.FromSeconds(5); }
        }
    }

    public static string Level(string role, string module)
    {
        if (role == "admin") return "write";
        lock (Lock) return _perms.TryGetValue("r_" + role + "|" + module, out var a) ? a : "write";
    }

    // فراخوانی از میان‌افزار ورود: اگر مجاز نباشد ApiException(403) می‌اندازد.
    public static async Task Check(HttpContext ctx, CurrentUser user)
    {
        if (user.IsAdmin) return;
        var path = ctx.Request.Path.Value ?? "";
        var write = !(ctx.Request.Method == "GET" || ctx.Request.Method == "HEAD");
        string? module = null;

        if (path.StartsWith("/api/t/", StringComparison.OrdinalIgnoreCase))
        {
            var seg = path.Substring(7).Split('/', StringSplitOptions.RemoveEmptyEntries);
            if (seg.Length > 0) module = ModuleOfTable(seg[0]);
        }
        else if (path.Equals("/api/versions", StringComparison.OrdinalIgnoreCase) && !write)
        {
            string? kind = ctx.Request.Query["kind"];
            if (!string.IsNullOrEmpty(kind)) module = ModuleOfVersionKind(kind);
        }
        else if (path.StartsWith("/api/versions/", StringComparison.OrdinalIgnoreCase) && write)
        {
            var seg = path.Substring(14).Split('/', StringSplitOptions.RemoveEmptyEntries);
            if (seg.Length == 1) module = ModuleOfVersionKind(seg[0]);   // ذخیرهٔ نسخهٔ جدید
        }
        if (module == null) return;

        await Refresh(ctx.RequestServices);
        var lvl = Level(user.Role, module);
        if (lvl == "none")
            throw new ApiException(403, "دسترسی نقش شما به این بخش بسته شده است.");
        if (write && lvl != "write")
            throw new ApiException(403, "نقش شما در این بخش فقط اجازهٔ مشاهده دارد، نه تغییر.");
    }
}
