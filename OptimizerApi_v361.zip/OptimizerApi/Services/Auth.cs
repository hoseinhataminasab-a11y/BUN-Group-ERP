using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Dapper;
using OptimizerApi.Data;

namespace OptimizerApi.Services;

// ---------- هش رمز (PBKDF2-SHA256، رمز خام هرگز ذخیره نمی‌شود) ----------
public static class PasswordHasher
{
    private const int Iterations = 210_000;

    public static string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);
        return $"pbkdf2${Iterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
    }

    public static bool Verify(string password, string? stored)
    {
        if (string.IsNullOrEmpty(stored)) return false;
        var parts = stored.Split('$');
        if (parts.Length != 4 || parts[0] != "pbkdf2") return false;
        if (!int.TryParse(parts[1], out var iter)) return false;
        var salt = Convert.FromBase64String(parts[2]);
        var expected = Convert.FromBase64String(parts[3]);
        var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, iter, HashAlgorithmName.SHA256, expected.Length);
        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }
}

// ---------- توکن ورود (JWT با امضای HS256؛ بدون وابستگی به پکیج اضافه) ----------
public class JwtService
{
    private readonly byte[] _key;
    public int Hours { get; }

    public JwtService(IConfiguration cfg, ILogger<JwtService> log)
    {
        var k = cfg["Jwt:Key"];
        if (!string.IsNullOrWhiteSpace(k) && k.Length >= 32)
            _key = Encoding.UTF8.GetBytes(k);
        else
        {
            // کلید ثابت و مخفی از روی کانکشن‌استرینگ (که رمز دیتابیس در آن است) ساخته می‌شود؛
            // پس با خاموش/روشن شدن API توکن‌ها معتبر می‌مانند و نیازی به تنظیم دستی نیست.
            var cs = cfg["ConnectionStrings:Optimizer"] ?? "";
            _key = SHA256.HashData(Encoding.UTF8.GetBytes("optimizer-jwt-v1|" + cs));
            if (cs.Length == 0) log.LogWarning("Jwt:Key و ConnectionStrings تنظیم نیست؛ کلید ضعیف است.");
        }
        Hours = int.TryParse(cfg["Jwt:ExpiresHours"], out var h) && h > 0 ? h : 12;
    }

    private static string B64(byte[] b) => Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_');

    private static byte[] UnB64(string s)
    {
        s = s.Replace('-', '+').Replace('_', '/');
        switch (s.Length % 4) { case 2: s += "=="; break; case 3: s += "="; break; }
        return Convert.FromBase64String(s);
    }

    private byte[] Sign(string data)
    {
        using var h = new HMACSHA256(_key);
        return h.ComputeHash(Encoding.UTF8.GetBytes(data));
    }

    public (string token, DateTime expiresAt) Create(CurrentUser u)
    {
        var now = DateTimeOffset.UtcNow;
        var exp = now.AddHours(Hours);
        var header = B64(Encoding.UTF8.GetBytes("{\"alg\":\"HS256\",\"typ\":\"JWT\"}"));
        var payload = B64(JsonSerializer.SerializeToUtf8Bytes(new Dictionary<string, object>
        {
            ["sub"] = u.Id,
            ["email"] = u.Email,
            ["name"] = u.Name,
            ["role"] = u.Role,
            ["iat"] = now.ToUnixTimeSeconds(),
            ["exp"] = exp.ToUnixTimeSeconds()
        }));
        var data = header + "." + payload;
        return (data + "." + B64(Sign(data)), exp.UtcDateTime);
    }

    public CurrentUser? Validate(string token)
    {
        try
        {
            var parts = token.Split('.');
            if (parts.Length != 3) return null;
            var expectedSig = Sign(parts[0] + "." + parts[1]);
            if (!CryptographicOperations.FixedTimeEquals(expectedSig, UnB64(parts[2]))) return null;
            using var doc = JsonDocument.Parse(UnB64(parts[1]));
            var r = doc.RootElement;
            if (r.GetProperty("exp").GetInt64() < DateTimeOffset.UtcNow.ToUnixTimeSeconds()) return null;
            return new CurrentUser(
                r.GetProperty("sub").GetString() ?? "",
                r.GetProperty("email").GetString() ?? "",
                r.GetProperty("name").GetString() ?? "",
                r.GetProperty("role").GetString() ?? "");
        }
        catch { return null; }
    }
}

// ---------- دروازهٔ ورود: همهٔ /api/* به‌جز login نیاز به توکن دارد ----------
public static class AuthMiddleware
{
    private static readonly string[] LegacyPrefixes =
    {
        "/api/materials", "/api/products", "/api/litho", "/api/printers", "/api/binderies",
        "/api/coverprinters", "/api/forms", "/api/paperspecs", "/api/settings"
    };

    public static IApplicationBuilder UseApiAuth(this IApplicationBuilder app)
    {
        return app.Use(async (ctx, next) =>
        {
            var path = ctx.Request.Path.Value ?? "";
            if (ctx.Request.Method == "OPTIONS" || !path.StartsWith("/api/", StringComparison.OrdinalIgnoreCase)
                || path.Equals("/api/auth/login", StringComparison.OrdinalIgnoreCase))
            {
                await next();
                return;
            }

            var jwt = ctx.RequestServices.GetRequiredService<JwtService>();
            var header = ctx.Request.Headers["Authorization"].ToString();
            CurrentUser? user = null;
            if (header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                user = jwt.Validate(header.Substring(7).Trim());

            if (user == null)
            {
                ctx.Response.StatusCode = 401;
                await ctx.Response.WriteAsJsonAsync(new { error = "ورود لازم است (توکن نامعتبر یا منقضی شده)." });
                return;
            }
            ctx.Items["user"] = user;

            // endpointهای قدیمی (اطلاعات پایه) فقط برای نوشتن به نقش مدیر کل / کارشناس تولید باز هستند
            var isWrite = !(ctx.Request.Method == "GET" || ctx.Request.Method == "HEAD");
            if (isWrite && LegacyPrefixes.Any(p => path.Equals(p, StringComparison.OrdinalIgnoreCase)
                                                   || path.StartsWith(p + "/", StringComparison.OrdinalIgnoreCase)))
            {
                if (user.Role != "admin" && user.Role != "prod")
                {
                    ctx.Response.StatusCode = 403;
                    await ctx.Response.WriteAsJsonAsync(new { error = "شما اجازهٔ ویرایش اطلاعات پایه را ندارید." });
                    return;
                }
            }
            await AccessPolicy.Check(ctx, user);   // v261: دسترسی ماژول در خود سرور
            await next();
        });
    }
}

// ---------- ساخت نقش‌ها و کاربر مدیر اول (فقط اگر هنوز نباشد) ----------
public static class Seeder
{
    public static async Task RunAsync(IServiceProvider sp, IConfiguration cfg)
    {
        try
        {
            var db = sp.GetRequiredService<Db>();
            using var c = db.Open();

            await c.ExecuteAsync(@"
                MERGE AppRoles AS t
                USING (VALUES
                    (N'admin', N'مدیر کل', N'دسترسی کامل، تأیید نسخه‌ها، مدیریت کاربران'),
                    (N'prod',  N'کارشناس تولید', N'ویرایش اطلاعات پایه و برنامه تولید و اکچوال'),
                    (N'sales', N'کارشناس فروش', N'ویرایش اطلاعات و برنامه فروش')
                ) AS s (Id, Name, Description)
                ON t.Id = s.Id
                WHEN NOT MATCHED THEN INSERT (Id, Name, Description) VALUES (s.Id, s.Name, s.Description);");

            var hasAdmin = await c.ExecuteScalarAsync<int>(
                "SELECT COUNT(1) FROM AppUsers WHERE RoleId = 'admin' AND PasswordHash IS NOT NULL AND IsActive = 1");
            if (hasAdmin > 0) return;

            var email = cfg["Auth:InitialAdminEmail"];
            if (string.IsNullOrWhiteSpace(email)) email = "admin";
            var pw = cfg["Auth:InitialAdminPassword"];
            var generated = false;
            if (string.IsNullOrWhiteSpace(pw) || pw.Length < 8)
            {
                const string alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
                var sb = new StringBuilder();
                for (int i = 0; i < 12; i++) sb.Append(alphabet[RandomNumberGenerator.GetInt32(alphabet.Length)]);
                pw = sb.ToString();
                generated = true;
            }
            var hash = PasswordHasher.Hash(pw);

            var exists = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppUsers WHERE Email = @e", new { e = email });
            if (exists > 0)
                await c.ExecuteAsync(
                    "UPDATE AppUsers SET PasswordHash=@h, RoleId='admin', IsActive=1, MustChangePassword=1, FailedLogins=0, LockedUntil=NULL WHERE Email=@e",
                    new { h = hash, e = email });
            else
                await c.ExecuteAsync(
                    "INSERT INTO AppUsers (Id, Email, FullName, RoleId, IsActive, PasswordHash, MustChangePassword) VALUES (@id, @e, N'مدیر سیستم', 'admin', 1, @h, 1)",
                    new { id = "u" + Guid.NewGuid().ToString("N").Substring(0, 10), e = email, h = hash });

            Console.WriteLine();
            Console.WriteLine("==============================================================");
            Console.WriteLine(" کاربر مدیر اول ساخته شد (این پیام فقط یک بار نمایش داده می‌شود)");
            Console.WriteLine("   نام کاربری: " + email);
            if (generated) Console.WriteLine("   رمز موقت  : " + pw);
            else Console.WriteLine("   رمز       : همان که در تنظیمات Auth:InitialAdminPassword دادید");
            Console.WriteLine(" در اولین ورود باید رمز را عوض کنید.");
            Console.WriteLine("==============================================================");
            Console.WriteLine();
        }
        catch (Exception ex)
        {
            Console.WriteLine("هشدار: ساخت نقش‌ها/مدیر اول انجام نشد (آیا اسکریپت فاز ۳ اجرا شده؟): " + ex.Message);
        }
    }
}
