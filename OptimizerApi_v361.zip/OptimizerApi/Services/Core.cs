using System.Data;
using System.Globalization;
using System.Text.Json;
using Dapper;
using Microsoft.Data.SqlClient;
using OptimizerApi.Data;

namespace OptimizerApi.Services;

// خطایی که پیامش مستقیم (با کد HTTP) به کاربر برمی‌گردد.
public class ApiException : Exception
{
    public int Status { get; }
    public ApiException(int status, string message) : base(message) { Status = status; }
}

// کاربر واردشده (از توکن خوانده می‌شود).
public record CurrentUser(string Id, string Email, string Name, string Role)
{
    public bool IsAdmin => Role == "admin";
}

public static class Ctx
{
    public static CurrentUser User(HttpContext c) =>
        c.Items["user"] as CurrentUser ?? throw new ApiException(401, "ابتدا وارد شوید.");

    public static CurrentUser Require(HttpContext c, params string[] roles)
    {
        var u = User(c);
        if (!roles.Contains(u.Role)) throw new ApiException(403, "شما اجازهٔ این کار را ندارید.");
        return u;
    }
}

// ---------- اطلاعات ساختار جدول‌ها (از خود SQL Server خوانده می‌شود، پس هر جدول جدید خودکار پشتیبانی می‌شود) ----------
public record ColInfo(string Name, string SqlType, bool IsNullable, bool IsIdentity, int PkOrder, int MaxLen)
{
    public bool IsPk => PkOrder > 0;
}

public class TableInfo
{
    public string Name { get; set; } = "";
    public List<ColInfo> Cols { get; } = new();
    public Dictionary<string, ColInfo> ByLower { get; } = new();
    public List<ColInfo> Pk => Cols.Where(c => c.IsPk).OrderBy(c => c.PkOrder).ToList();
    public bool Has(string n) => ByLower.ContainsKey(n.ToLowerInvariant());
}

public class SchemaCache
{
    private readonly Db _db;
    private Task<Dictionary<string, TableInfo>>? _task;
    public SchemaCache(Db db) { _db = db; }

    private class MetaRow
    {
        public string TableName { get; set; } = "";
        public string ColName { get; set; } = "";
        public string SqlType { get; set; } = "";
        public bool IsNullable { get; set; }
        public bool IsIdentity { get; set; }
        public int MaxLen { get; set; }
        public int PkOrder { get; set; }
    }

    private async Task<Dictionary<string, TableInfo>> Load()
    {
        using var c = _db.Open();
        var rows = await c.QueryAsync<MetaRow>(@"
            SELECT t.name AS TableName, c.name AS ColName, ty.name AS SqlType,
                   c.is_nullable AS IsNullable, c.is_identity AS IsIdentity,
                   CAST(c.max_length AS int) AS MaxLen,
                   CAST(ISNULL(ic.key_ordinal, 0) AS int) AS PkOrder
            FROM sys.tables t
            JOIN sys.columns c ON c.object_id = t.object_id
            JOIN sys.types ty ON ty.user_type_id = c.user_type_id
            LEFT JOIN sys.indexes i ON i.object_id = t.object_id AND i.is_primary_key = 1
            LEFT JOIN sys.index_columns ic ON ic.object_id = t.object_id AND ic.index_id = i.index_id AND ic.column_id = c.column_id
            ORDER BY t.name, c.column_id");
        var result = new Dictionary<string, TableInfo>(StringComparer.OrdinalIgnoreCase);
        foreach (var r in rows)
        {
            if (!result.TryGetValue(r.TableName, out var t))
            {
                t = new TableInfo { Name = r.TableName };
                result[r.TableName] = t;
            }
            var ci = new ColInfo(r.ColName, r.SqlType, r.IsNullable, r.IsIdentity, r.PkOrder, r.MaxLen);
            t.Cols.Add(ci);
            t.ByLower[r.ColName.ToLowerInvariant()] = ci;
        }
        return result;
    }

    public async Task<Dictionary<string, TableInfo>> GetAsync()
    {
        var task = _task ??= Load();
        try { return await task; }
        catch { _task = null; throw; }
    }

    public async Task<TableInfo?> FindAsync(string name)
    {
        var all = await GetAsync();
        return all.TryGetValue(name, out var t) ? t : null;
    }
}

// ---------- تبدیل JSON ↔ SQL ----------
public static class Conv
{
    public static string CamelName(string n) => n.Length == 0 ? n : char.ToLowerInvariant(n[0]) + n.Substring(1);

    public static Type Clr(string sqlType) => sqlType switch
    {
        "tinyint" => typeof(byte),
        "smallint" => typeof(short),
        "int" => typeof(int),
        "bigint" => typeof(long),
        "bit" => typeof(bool),
        "decimal" or "numeric" or "money" or "smallmoney" => typeof(decimal),
        "float" => typeof(double),
        "real" => typeof(float),
        "date" or "datetime" or "datetime2" or "smalldatetime" => typeof(DateTime),
        "uniqueidentifier" => typeof(Guid),
        _ => typeof(string)
    };

    public static object? FromString(string s, ColInfo c) => FromJson(JsonSerializer.SerializeToElement(s), c);

    public static object? FromJson(JsonElement e, ColInfo c)
    {
        if (e.ValueKind == JsonValueKind.Null || e.ValueKind == JsonValueKind.Undefined) return null;
        var t = Clr(c.SqlType);
        try
        {
            if (t == typeof(string))
                return e.ValueKind == JsonValueKind.String ? e.GetString() : e.GetRawText();

            string? s = e.ValueKind == JsonValueKind.String ? e.GetString() : null;
            if (s != null && s.Trim().Length == 0) return null;

            if (t == typeof(bool))
            {
                return e.ValueKind switch
                {
                    JsonValueKind.True => true,
                    JsonValueKind.False => false,
                    JsonValueKind.Number => e.GetDouble() != 0,
                    JsonValueKind.String => ParseBool(s!),
                    _ => throw new FormatException()
                };
            }
            if (t == typeof(DateTime))
            {
                if (s == null) throw new FormatException();
                var dt = DateTime.Parse(s, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
                return c.SqlType == "date" ? dt.Date : dt;
            }
            if (t == typeof(Guid))
            {
                if (s == null) throw new FormatException();
                return Guid.Parse(s);
            }
            if (t == typeof(double)) return e.ValueKind == JsonValueKind.Number ? e.GetDouble() : double.Parse(s!, NumberStyles.Float, CultureInfo.InvariantCulture);

            decimal d;
            if (e.ValueKind == JsonValueKind.Number)
                d = e.TryGetDecimal(out var dd) ? dd : (decimal)e.GetDouble();
            else if (e.ValueKind == JsonValueKind.String)
                d = decimal.Parse(s!, NumberStyles.Float, CultureInfo.InvariantCulture);
            else if (e.ValueKind == JsonValueKind.True) d = 1;
            else if (e.ValueKind == JsonValueKind.False) d = 0;
            else throw new FormatException();

            if (t == typeof(decimal)) return d;
            if (t == typeof(float)) return (float)d;
            var r = Math.Round(d, MidpointRounding.AwayFromZero);
            if (t == typeof(byte)) return checked((byte)r);
            if (t == typeof(short)) return checked((short)r);
            if (t == typeof(int)) return checked((int)r);
            if (t == typeof(long)) return checked((long)r);
            return d;
        }
        catch (Exception ex) when (ex is FormatException or OverflowException or InvalidOperationException or ArgumentException)
        {
            var raw = e.GetRawText();
            if (raw.Length > 60) raw = raw.Substring(0, 60) + "…";
            throw new ApiException(400, $"مقدار نامعتبر برای ستون «{c.Name}» ({c.SqlType}): {raw}");
        }
    }

    private static bool ParseBool(string s)
    {
        var v = s.Trim().ToLowerInvariant();
        if (v is "1" or "true" or "yes" or "y") return true;
        if (v is "0" or "false" or "no" or "n") return false;
        throw new FormatException();
    }

    // نتیجهٔ Dapper (dynamic) → لیست دیکشنری با نام‌های camelCase (هم‌نام فیلدهای جاوااسکریپت برنامه)
    public static List<Dictionary<string, object?>> ToDicts(IEnumerable<dynamic> rows)
    {
        var list = new List<Dictionary<string, object?>>();
        foreach (var r in rows)
        {
            var d = (IDictionary<string, object>)r;
            var o = new Dictionary<string, object?>();
            foreach (var kv in d) o[CamelName(kv.Key)] = kv.Value is DBNull ? null : kv.Value;
            list.Add(o);
        }
        return list;
    }

    // درج انبوه سریع (SqlBulkCopy). فقط ستون‌هایی که در داده‌ها دیده می‌شوند نگاشت می‌شوند؛ بقیه مقدار پیش‌فرض خودشان را می‌گیرند.
    public static async Task<int> BulkInsertAsync(SqlConnection c, SqlTransaction? tx, TableInfo t,
        IReadOnlyList<JsonElement> rows, Dictionary<string, object?>? constants = null)
    {
        if (rows.Count == 0) return 0;
        var used = new List<ColInfo>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (constants != null)
            foreach (var k in constants.Keys)
                if (t.ByLower.TryGetValue(k.ToLowerInvariant(), out var cc) && seen.Add(cc.Name)) used.Add(cc);
        foreach (var r in rows)
        {
            if (r.ValueKind != JsonValueKind.Object) throw new ApiException(400, "هر ردیف باید یک شیء JSON باشد.");
            foreach (var p in r.EnumerateObject())
                if (t.ByLower.TryGetValue(p.Name.ToLowerInvariant(), out var cc) && !cc.IsIdentity && seen.Add(cc.Name)) used.Add(cc);
        }
        if (used.Count == 0) return 0;

        var dt = new DataTable();
        foreach (var cc in used) dt.Columns.Add(cc.Name, Clr(cc.SqlType));

        foreach (var r in rows)
        {
            var lookup = new Dictionary<string, JsonElement>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in r.EnumerateObject()) lookup[p.Name] = p.Value;
            var vals = new object[used.Count];
            for (int i = 0; i < used.Count; i++)
            {
                var col = used[i];
                object? v = null;
                if (constants != null && constants.TryGetValue(col.Name, out var cv)) v = cv;
                else if (lookup.TryGetValue(col.Name, out var je)) v = FromJson(je, col);
                vals[i] = v ?? DBNull.Value;
            }
            dt.Rows.Add(vals);
        }

        using var bc = new SqlBulkCopy(c, SqlBulkCopyOptions.Default, tx)
        {
            DestinationTableName = "[" + t.Name + "]",
            BulkCopyTimeout = 600,
            BatchSize = 5000
        };
        foreach (var cc in used) bc.ColumnMappings.Add(cc.Name, cc.Name);
        await bc.WriteToServerAsync(dt);
        return dt.Rows.Count;
    }
}

// ---------- ثبت رویدادها (AuditLog) ----------
public class AuditService
{
    private readonly Db _db;
    public AuditService(Db db) { _db = db; }

    private static string? Cut(string? s, int n) => s == null ? null : (s.Length <= n ? s : s.Substring(0, n));

    public async Task LogAsync(CurrentUser? u, string action, string? entity = null, string? id = null, string? detail = null)
    {
        try
        {
            using var c = _db.Open();
            await c.ExecuteAsync(
                "INSERT INTO AuditLog (UserId, UserEmail, Action, EntityName, EntityId, Detail) VALUES (@uid, @mail, @act, @ent, @eid, @det)",
                new { uid = Cut(u?.Id, 30), mail = Cut(u?.Email, 200), act = Cut(action, 30), ent = Cut(entity, 60), eid = Cut(id, 60), det = detail });
        }
        catch { /* ثبت لاگ نباید کار اصلی را خراب کند */ }
    }
}
