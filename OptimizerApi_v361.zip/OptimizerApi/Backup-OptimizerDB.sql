-- پشتیبان‌گیری از دیتابیس (در SSMS اجرا کنید، یا از SQL Server Agent به‌صورت شبانه زمان‌بندی کنید).
-- مسیر D:\Backups را با پوشهٔ دلخواه روی سرور عوض کنید (پوشه باید وجود داشته باشد).
DECLARE @f NVARCHAR(300) = N'D:\Backups\OptimizerDB_' + REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), ':', '-') + N'.bak';
BACKUP DATABASE OptimizerDB TO DISK = @f WITH COMPRESSION, INIT;
