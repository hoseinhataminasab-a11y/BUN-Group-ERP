using Dapper;
using Microsoft.Data.SqlClient;
using OptimizerApi.Data;
using OptimizerApi.Models;
using System.Data;
using System.Linq;
using Microsoft.OpenApi.Models;
using OptimizerApi.Endpoints;
using OptimizerApi.Services;
using Microsoft.AspNetCore.ResponseCompression;
using System.IO.Compression;

// Dapper به‌صورت پیش‌فرض ستون date/datetime را به DateOnly تبدیل نمی‌کند (خطای «Error parsing column pdfReady»)؛
// این هندلر آن را حل می‌کند.
SqlMapper.AddTypeHandler(new DateOnlyTypeHandler());

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<Db>();
builder.Services.AddSingleton<SchemaCache>();
builder.Services.AddSingleton<JwtService>();
builder.Services.AddSingleton<AuditService>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "ابتدا از /api/auth/login توکن بگیرید و اینجا فقط خود توکن را بچسبانید."
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        { new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }, Array.Empty<string>() }
    });
});
// بارگذاری انبوه (مثلاً ۲۰ هزار ردیف گزارش توزیع‌کنندگان) به بدنهٔ بزرگ نیاز دارد
builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = 300_000_000);
builder.Services.ConfigureHttpJsonOptions(o => { o.SerializerOptions.PropertyNameCaseInsensitive = true; });

var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? new[] { "*" };
builder.Services.AddCors(opt =>
{
    opt.AddDefaultPolicy(policy =>
    {
        if (allowedOrigins.Length == 1 && allowedOrigins[0] == "*")
            policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader().WithExposedHeaders("X-Doc-Version", "X-Doc-Updated-At", "X-Doc-Updated-By");
        else
            policy.WithOrigins(allowedOrigins).AllowAnyMethod().AllowAnyHeader().WithExposedHeaders("X-Doc-Version", "X-Doc-Updated-At", "X-Doc-Updated-By");
    });
});

// v330 — فشرده‌سازی پاسخ‌ها (Brotli/Gzip): فایل ۶ مگابایتی برنامه با حدود ۱ مگابایت منتقل می‌شود
builder.Services.AddResponseCompression(o =>
{
    o.EnableForHttps = true;
    o.Providers.Add<BrotliCompressionProvider>();
    o.Providers.Add<GzipCompressionProvider>();
    o.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "text/html", "application/json", "image/svg+xml" });
});
builder.Services.Configure<BrotliCompressionProviderOptions>(o => o.Level = CompressionLevel.Fastest);
builder.Services.Configure<GzipCompressionProviderOptions>(o => o.Level = CompressionLevel.Fastest);

var app = builder.Build();
app.UseResponseCompression();

// خود برنامه (HTML) از پوشهٔ wwwroot/index.html همین API سرو می‌شود؛ پس کاربران فقط آدرس سرور را باز می‌کنند.
app.UseDefaultFiles();
app.UseStaticFiles(new StaticFileOptions
{
    // نسخهٔ برنامه با ETag کنترل می‌شود: مرورگر هر بار فقط می‌پرسد «تغییر کرده؟» و اگر نه، از حافظهٔ خودش باز می‌کند
    OnPrepareResponse = ctx => { ctx.Context.Response.Headers["Cache-Control"] = "no-cache"; }
});
app.UseSwagger();
app.UseSwaggerUI();
app.UseCors();

// خطاهای قابل‌فهم به‌جای صفحهٔ خطای خام
app.Use(async (ctx, next) =>
{
    try { await next(); }
    catch (Exception ex) when (!ctx.Response.HasStarted)
    {
        int status; string msg;
        switch (ex)
        {
            case ApiException ae: status = ae.Status; msg = ae.Message; break;
            case SqlException se when se.Number == 547: status = 409; msg = "این رکورد در جای دیگری استفاده شده و حذف/تغییر نمی‌شود. (" + se.Message + ")"; break;
            case SqlException se when se.Number == 2627 || se.Number == 2601: status = 409; msg = "مقدار تکراری برای کلید یا فیلد یکتا. (" + se.Message + ")"; break;
            case SqlException se: status = 400; msg = se.Message; break;
            case System.Text.Json.JsonException: case BadHttpRequestException: case FormatException: case OverflowException:
                status = 400; msg = "درخواست نامعتبر: " + ex.Message; break;
            default:
                Console.WriteLine(ex);
                status = 500; msg = "خطای داخلی سرور: " + ex.Message; break;
        }
        ctx.Response.StatusCode = status;
        await ctx.Response.WriteAsJsonAsync(new { error = msg });
    }
});
app.UseApiAuth();

// ===================== Materials =====================
app.MapGet("/api/materials", async (Db db) =>
{
    using var c = db.Open();
    var rows = await c.QueryAsync<Material>("SELECT Id AS id, Kind AS kind, Category AS category, Name AS name, RefFormType AS refFormType, SheetLen AS sheetLen, SheetWidth AS sheetWidth, Grammage AS grammage, WeightPerSheet AS weightPerSheet, PackQty AS packQty, PricePerPack AS pricePerPack, PricePerKg AS pricePerKg, CreditLTMonths AS creditLTMonths, CreditSurchargePctPerMonth AS creditSurchargePctPerMonth, InventoryKg AS inventoryKg, LeadTimeMonths AS leadTimeMonths FROM Materials");
    return Results.Ok(rows);
});

app.MapPut("/api/materials/{id}", async (string id, Material m, Db db) =>
{
    using var c = db.Open();
    var n = await c.ExecuteAsync(@"
        MERGE Materials AS t USING (SELECT @id AS Id) AS s ON t.Id = s.Id
        WHEN MATCHED THEN UPDATE SET Kind=@kind, Category=@category, Name=@name, RefFormType=@refFormType,
            SheetLen=@sheetLen, SheetWidth=@sheetWidth, Grammage=@grammage, WeightPerSheet=@weightPerSheet,
            PackQty=@packQty, PricePerPack=@pricePerPack, PricePerKg=@pricePerKg, CreditLTMonths=@creditLTMonths,
            CreditSurchargePctPerMonth=@creditSurchargePctPerMonth, InventoryKg=@inventoryKg, LeadTimeMonths=@leadTimeMonths,
            UpdatedAt=SYSUTCDATETIME()
        WHEN NOT MATCHED THEN INSERT (Id,Kind,Category,Name,RefFormType,SheetLen,SheetWidth,Grammage,WeightPerSheet,PackQty,PricePerPack,PricePerKg,CreditLTMonths,CreditSurchargePctPerMonth,InventoryKg,LeadTimeMonths)
            VALUES (@id,@kind,@category,@name,@refFormType,@sheetLen,@sheetWidth,@grammage,@weightPerSheet,@packQty,@pricePerPack,@pricePerKg,@creditLTMonths,@creditSurchargePctPerMonth,@inventoryKg,@leadTimeMonths);",
        new { id, m.kind, m.category, m.name, m.refFormType, m.sheetLen, m.sheetWidth, m.grammage, m.weightPerSheet, m.packQty, m.pricePerPack, m.pricePerKg, m.creditLTMonths, m.creditSurchargePctPerMonth, m.inventoryKg, m.leadTimeMonths });
    return Results.Ok(new { updated = n });
});

app.MapDelete("/api/materials/{id}", async (string id, Db db) =>
{
    using var c = db.Open();
    await c.ExecuteAsync("DELETE FROM Materials WHERE Id=@id", new { id });
    return Results.NoContent();
});

// ===================== Products =====================
app.MapGet("/api/products", async (Db db) =>
{
    using var c = db.Open();
    var rows = await c.QueryAsync<Product>(@"SELECT Id AS id, Code AS code, Name AS name, Publisher AS publisher, Basket AS basket,
        TrimTitle AS trim, Pages AS pages, ColorCount AS colorCount, MarginPct AS marginPct, MarginAmt AS marginAmt,
        BudgetUnitCost AS budgetUnitCost, PdfReady AS pdfReady, Forecast AS forecast, Inventory AS inventory,
        StockPolicy AS stockPolicy, MaxBatch AS maxBatch, SalePrice AS salePrice, MaterialId AS materialId,
        HasLatFee AS hasLatFee, ForecastAuto AS forecastAuto, MaxShelfLifeYears AS maxShelfLifeYears, RoyaltyPct AS royaltyPct
        FROM Products");
    return Results.Ok(rows);
});

app.MapPut("/api/products/{id}", async (string id, Product p, Db db) =>
{
    using var c = db.Open();
    var n = await c.ExecuteAsync(@"
        MERGE Products AS t USING (SELECT @id AS Id) AS s ON t.Id = s.Id
        WHEN MATCHED THEN UPDATE SET Code=@code, Name=@name, Publisher=@publisher, Basket=@basket, TrimTitle=@trim,
            Pages=@pages, ColorCount=@colorCount, MarginPct=@marginPct, MarginAmt=@marginAmt, BudgetUnitCost=@budgetUnitCost,
            PdfReady=@pdfReady, Forecast=@forecast, Inventory=@inventory, StockPolicy=@stockPolicy, MaxBatch=@maxBatch,
            SalePrice=@salePrice, MaterialId=@materialId, HasLatFee=@hasLatFee, ForecastAuto=@forecastAuto,
            MaxShelfLifeYears=@maxShelfLifeYears, RoyaltyPct=@royaltyPct, UpdatedAt=SYSUTCDATETIME()
        WHEN NOT MATCHED THEN INSERT (Id,Code,Name,Publisher,Basket,TrimTitle,Pages,ColorCount,MarginPct,MarginAmt,BudgetUnitCost,PdfReady,Forecast,Inventory,StockPolicy,MaxBatch,SalePrice,MaterialId,HasLatFee,ForecastAuto,MaxShelfLifeYears,RoyaltyPct)
            VALUES (@id,@code,@name,@publisher,@basket,@trim,@pages,@colorCount,@marginPct,@marginAmt,@budgetUnitCost,@pdfReady,@forecast,@inventory,@stockPolicy,@maxBatch,@salePrice,@materialId,@hasLatFee,@forecastAuto,@maxShelfLifeYears,@royaltyPct);",
        new { id, p.code, p.name, p.publisher, p.basket, p.trim, p.pages, p.colorCount, p.marginPct, p.marginAmt, p.budgetUnitCost, p.pdfReady, p.forecast, p.inventory, p.stockPolicy, p.maxBatch, p.salePrice, p.materialId, p.hasLatFee, p.forecastAuto, p.maxShelfLifeYears, p.royaltyPct });
    return Results.Ok(new { updated = n });
});

app.MapDelete("/api/products/{id}", async (string id, Db db) =>
{
    using var c = db.Open();
    await c.ExecuteAsync("DELETE FROM Products WHERE Id=@id", new { id });
    return Results.NoContent();
});

// ===================== Contractors (Litho / Printers / Binderies / CoverPrinters) =====================
// هر ۴ گروه یک الگوی مشترک دارند: سرآیند پیمانکار + آرایه‌ای از ردیف‌های فرم (formLines).
// در برنامهٔ فعلی، ذخیره همیشه «کل شیء پیمانکار به‌همراه همهٔ formLines اش» است، پس همین رفتار
// اینجا هم حفظ شده: هر PUT روی یک پیمانکار، تمام formLines قبلی همان پیمانکار را با نسخهٔ جدید
// جایگزین می‌کند (Delete+Insert در یک تراکنش).

app.MapGet("/api/litho", async (Db db) => Results.Ok(await GetContractorsWithFormLines<LithoContractor>(db,
    "SELECT Id AS id, ContractorCode AS contractorCode, Name AS name, Tech AS tech, Trim AS trim FROM LithoContractors",
    "SELECT Id AS id, LithoId AS ParentId, FormType AS formType, Rate AS rate, PagesPerForm AS pagesPerForm, MonthlyCapsJson AS MonthlyCapsJson FROM LithoFormLines")));

app.MapPut("/api/litho/{id}", async (string id, LithoContractor x, Db db) =>
{
    using var c = db.Open();
    using var tx = c.BeginTransaction();
    await c.ExecuteAsync(@"
        MERGE LithoContractors AS t USING (SELECT @id AS Id) AS s ON t.Id=s.Id
        WHEN MATCHED THEN UPDATE SET ContractorCode=@contractorCode, Name=@name, Tech=@tech, Trim=@trim, UpdatedAt=SYSUTCDATETIME()
        WHEN NOT MATCHED THEN INSERT (Id,ContractorCode,Name,Tech,Trim) VALUES (@id,@contractorCode,@name,@tech,@trim);",
        new { id, x.contractorCode, x.name, x.tech, x.trim }, tx);
    await c.ExecuteAsync("DELETE FROM LithoFormLines WHERE LithoId=@id", new { id }, tx);
    foreach (var fl in x.formLines)
        await c.ExecuteAsync("INSERT INTO LithoFormLines (LithoId,FormType,Rate,PagesPerForm,MonthlyCapsJson) VALUES (@id,@formType,@rate,@pagesPerForm,@caps)",
            new { id, fl.formType, fl.rate, fl.pagesPerForm, caps = fl.monthlyCaps == null ? null : System.Text.Json.JsonSerializer.Serialize(fl.monthlyCaps) }, tx);
    tx.Commit();
    return Results.Ok(new { saved = true });
});
app.MapDelete("/api/litho/{id}", async (string id, Db db) => { using var c = db.Open(); await c.ExecuteAsync("DELETE FROM LithoContractors WHERE Id=@id", new { id }); return Results.NoContent(); });

app.MapGet("/api/printers", async (Db db) => Results.Ok(await GetContractorsWithFormLines<PrinterContractor>(db,
    "SELECT Id AS id, ContractorCode AS contractorCode, Printer AS printer, Machine AS machine, Tech AS tech, ColorCap AS colorCap, Waste AS waste, ScissorWidth AS scissorWidth, RequiredCutoff AS requiredCutoff, MazandaranSurchargePct AS mazandaranSurchargePct FROM PrinterContractors",
    "SELECT Id AS id, PrinterId AS ParentId, FormType AS formType, Rate AS rate, A4InForm AS a4InForm, ColorCount AS colorCount, Coefficient AS coefficient, MinRunSheets AS minRunSheets, PricePerColorBase AS pricePerColorBase, MonthlyCapA4 AS monthlyCapA4, MonthlyCapsJson AS MonthlyCapsJson FROM PrinterFormLines")));

app.MapPut("/api/printers/{id}", async (string id, PrinterContractor x, Db db) =>
{
    using var c = db.Open();
    using var tx = c.BeginTransaction();
    await c.ExecuteAsync(@"
        MERGE PrinterContractors AS t USING (SELECT @id AS Id) AS s ON t.Id=s.Id
        WHEN MATCHED THEN UPDATE SET ContractorCode=@contractorCode, Printer=@printer, Machine=@machine, Tech=@tech,
            ColorCap=@colorCap, Waste=@waste, ScissorWidth=@scissorWidth, RequiredCutoff=@requiredCutoff,
            MazandaranSurchargePct=@mazandaranSurchargePct, UpdatedAt=SYSUTCDATETIME()
        WHEN NOT MATCHED THEN INSERT (Id,ContractorCode,Printer,Machine,Tech,ColorCap,Waste,ScissorWidth,RequiredCutoff,MazandaranSurchargePct)
            VALUES (@id,@contractorCode,@printer,@machine,@tech,@colorCap,@waste,@scissorWidth,@requiredCutoff,@mazandaranSurchargePct);",
        new { id, x.contractorCode, x.printer, x.machine, x.tech, x.colorCap, x.waste, x.scissorWidth, x.requiredCutoff, x.mazandaranSurchargePct }, tx);
    await c.ExecuteAsync("DELETE FROM PrinterFormLines WHERE PrinterId=@id", new { id }, tx);
    foreach (var fl in x.formLines)
        await c.ExecuteAsync(@"INSERT INTO PrinterFormLines (PrinterId,FormType,Rate,A4InForm,ColorCount,Coefficient,MinRunSheets,PricePerColorBase,MonthlyCapA4,MonthlyCapsJson)
            VALUES (@id,@formType,@rate,@a4InForm,@colorCount,@coefficient,@minRunSheets,@pricePerColorBase,@monthlyCapA4,@caps)",
            new { id, fl.formType, fl.rate, fl.a4InForm, fl.colorCount, fl.coefficient, fl.minRunSheets, fl.pricePerColorBase, fl.monthlyCapA4, caps = fl.monthlyCaps == null ? null : System.Text.Json.JsonSerializer.Serialize(fl.monthlyCaps) }, tx);
    tx.Commit();
    return Results.Ok(new { saved = true });
});
app.MapDelete("/api/printers/{id}", async (string id, Db db) => { using var c = db.Open(); await c.ExecuteAsync("DELETE FROM PrinterContractors WHERE Id=@id", new { id }); return Results.NoContent(); });

app.MapGet("/api/binderies", async (Db db) => Results.Ok(await GetContractorsWithFormLines<BinderyContractor>(db,
    "SELECT Id AS id, ContractorCode AS contractorCode, Name AS name, BindType AS bindType, Trim AS trim FROM BinderyContractors",
    "SELECT Id AS id, BinderyId AS ParentId, FormType AS formType, Rate AS rate, PagesPerForm AS pagesPerForm, MonthlyCapsJson AS MonthlyCapsJson FROM BinderyFormLines")));

app.MapPut("/api/binderies/{id}", async (string id, BinderyContractor x, Db db) =>
{
    using var c = db.Open();
    using var tx = c.BeginTransaction();
    await c.ExecuteAsync(@"
        MERGE BinderyContractors AS t USING (SELECT @id AS Id) AS s ON t.Id=s.Id
        WHEN MATCHED THEN UPDATE SET ContractorCode=@contractorCode, Name=@name, BindType=@bindType, Trim=@trim, UpdatedAt=SYSUTCDATETIME()
        WHEN NOT MATCHED THEN INSERT (Id,ContractorCode,Name,BindType,Trim) VALUES (@id,@contractorCode,@name,@bindType,@trim);",
        new { id, x.contractorCode, x.name, x.bindType, x.trim }, tx);
    await c.ExecuteAsync("DELETE FROM BinderyFormLines WHERE BinderyId=@id", new { id }, tx);
    foreach (var fl in x.formLines)
        await c.ExecuteAsync("INSERT INTO BinderyFormLines (BinderyId,FormType,Rate,PagesPerForm,MonthlyCapsJson) VALUES (@id,@formType,@rate,@pagesPerForm,@caps)",
            new { id, fl.formType, fl.rate, fl.pagesPerForm, caps = fl.monthlyCaps == null ? null : System.Text.Json.JsonSerializer.Serialize(fl.monthlyCaps) }, tx);
    tx.Commit();
    return Results.Ok(new { saved = true });
});
app.MapDelete("/api/binderies/{id}", async (string id, Db db) => { using var c = db.Open(); await c.ExecuteAsync("DELETE FROM BinderyContractors WHERE Id=@id", new { id }); return Results.NoContent(); });

app.MapGet("/api/coverprinters", async (Db db) => Results.Ok(await GetContractorsWithFormLines<CoverPrinterContractor>(db,
    "SELECT Id AS id, ContractorCode AS contractorCode, Name AS name FROM CoverPrinterContractors",
    "SELECT Id AS id, CoverId AS ParentId, FormType AS formType, ColorCount AS colorCount, Rate AS rate, PricePerColor AS pricePerColor, CoversPerForm AS coversPerForm, BaseTirage AS baseTirage, MonthlyCapsJson AS MonthlyCapsJson FROM CoverFormLines")));

app.MapPut("/api/coverprinters/{id}", async (string id, CoverPrinterContractor x, Db db) =>
{
    using var c = db.Open();
    using var tx = c.BeginTransaction();
    await c.ExecuteAsync(@"
        MERGE CoverPrinterContractors AS t USING (SELECT @id AS Id) AS s ON t.Id=s.Id
        WHEN MATCHED THEN UPDATE SET ContractorCode=@contractorCode, Name=@name, UpdatedAt=SYSUTCDATETIME()
        WHEN NOT MATCHED THEN INSERT (Id,ContractorCode,Name) VALUES (@id,@contractorCode,@name);",
        new { id, x.contractorCode, x.name }, tx);
    await c.ExecuteAsync("DELETE FROM CoverFormLines WHERE CoverId=@id", new { id }, tx);
    foreach (var fl in x.formLines)
        await c.ExecuteAsync(@"INSERT INTO CoverFormLines (CoverId,FormType,ColorCount,Rate,PricePerColor,CoversPerForm,BaseTirage,MonthlyCapsJson)
            VALUES (@id,@formType,@colorCount,@rate,@pricePerColor,@coversPerForm,@baseTirage,@caps)",
            new { id, fl.formType, fl.colorCount, fl.rate, fl.pricePerColor, fl.coversPerForm, fl.baseTirage, caps = fl.monthlyCaps == null ? null : System.Text.Json.JsonSerializer.Serialize(fl.monthlyCaps) }, tx);
    tx.Commit();
    return Results.Ok(new { saved = true });
});
app.MapDelete("/api/coverprinters/{id}", async (string id, Db db) => { using var c = db.Open(); await c.ExecuteAsync("DELETE FROM CoverPrinterContractors WHERE Id=@id", new { id }); return Results.NoContent(); });

// ===================== Forms (مرجع صفحه/فرم) =====================
app.MapGet("/api/forms", async (Db db) =>
{
    using var c = db.Open();
    return Results.Ok(await c.QueryAsync<FormRow>("SELECT Id AS id, Tech AS tech, Trim AS trim, A4InForm AS a4InForm, SheetType AS sheetType, FormType AS formType, PagesPerForm AS pagesPerForm FROM Forms"));
});
app.MapPost("/api/forms", async (FormRow f, Db db) =>
{
    using var c = db.Open();
    var newId = await c.ExecuteScalarAsync<int>(
        "INSERT INTO Forms (Tech,Trim,A4InForm,SheetType,FormType,PagesPerForm) OUTPUT INSERTED.Id VALUES (@tech,@trim,@a4InForm,@sheetType,@formType,@pagesPerForm)",
        new { f.tech, f.trim, f.a4InForm, f.sheetType, f.formType, f.pagesPerForm });
    return Results.Ok(new { id = newId });
});
app.MapDelete("/api/forms/{id:int}", async (int id, Db db) => { using var c = db.Open(); await c.ExecuteAsync("DELETE FROM Forms WHERE Id=@id", new { id }); return Results.NoContent(); });

// ===================== PaperSpecs =====================
app.MapGet("/api/paperspecs", async (Db db) =>
{
    using var c = db.Open();
    return Results.Ok(await c.QueryAsync<PaperSpec>("SELECT Id AS id, MaterialId AS materialId, TrimTitle AS trim, Dims AS dims, PageWeight AS pageWeight, WastePct AS wastePct, GrossConsumption AS grossConsumption, ConsumptionWithWaste AS consumptionWithWaste, SheetType AS sheetType, PagesPerSheet AS pagesPerSheet FROM PaperSpecs"));
});
app.MapPut("/api/paperspecs/{id}", async (string id, PaperSpec ps, Db db) =>
{
    using var c = db.Open();
    await c.ExecuteAsync(@"
        MERGE PaperSpecs AS t USING (SELECT @id AS Id) AS s ON t.Id=s.Id
        WHEN MATCHED THEN UPDATE SET MaterialId=@materialId, TrimTitle=@trim, Dims=@dims, PageWeight=@pageWeight,
            WastePct=@wastePct, GrossConsumption=@grossConsumption, ConsumptionWithWaste=@consumptionWithWaste,
            SheetType=@sheetType, PagesPerSheet=@pagesPerSheet
        WHEN NOT MATCHED THEN INSERT (Id,MaterialId,TrimTitle,Dims,PageWeight,WastePct,GrossConsumption,ConsumptionWithWaste,SheetType,PagesPerSheet)
            VALUES (@id,@materialId,@trim,@dims,@pageWeight,@wastePct,@grossConsumption,@consumptionWithWaste,@sheetType,@pagesPerSheet);",
        new { id, ps.materialId, ps.trim, ps.dims, ps.pageWeight, ps.wastePct, ps.grossConsumption, ps.consumptionWithWaste, ps.sheetType, ps.pagesPerSheet });
    return Results.Ok(new { saved = true });
});
app.MapDelete("/api/paperspecs/{id}", async (string id, Db db) => { using var c = db.Open(); await c.ExecuteAsync("DELETE FROM PaperSpecs WHERE Id=@id", new { id }); return Results.NoContent(); });

// ===================== Settings (کلید/مقدار) =====================
app.MapGet("/api/settings", async (Db db) =>
{
    using var c = db.Open();
    return Results.Ok(await c.QueryAsync<SettingItem>("SELECT SettingKey AS settingKey, SettingValue AS settingValue FROM Settings"));
});
app.MapPut("/api/settings/{key}", async (string key, SettingItem s, Db db) =>
{
    using var c = db.Open();
    await c.ExecuteAsync(@"
        MERGE Settings AS t USING (SELECT @key AS SettingKey) AS s ON t.SettingKey=s.SettingKey
        WHEN MATCHED THEN UPDATE SET SettingValue=@value, UpdatedAt=SYSUTCDATETIME()
        WHEN NOT MATCHED THEN INSERT (SettingKey,SettingValue) VALUES (@key,@value);",
        new { key, value = s.settingValue });
    return Results.Ok(new { saved = true });
});

// ===================== Master Data bundle (بارگذاری اولیهٔ کل state) =====================
// معادل همان چیزی که الان window.storage.get('ban_or_state_v3') برمی‌گرداند — برای فاز ۳
// (وصل‌کردن فرانت‌اند)، بارگذاری اولیه را با یک فراخوانی fetch('/api/masterdata') جایگزین کنید
// و ذخیره را به‌جای «کل state یک‌جا»، به فراخوانی‌های PUT جدا برای هر ردیف تغییریافته تبدیل کنید.
app.MapGet("/api/masterdata", async (Db db) =>
{
    using var c1 = db.Open();
    var materials = await c1.QueryAsync<Material>("SELECT Id AS id, Kind AS kind, Category AS category, Name AS name, RefFormType AS refFormType, SheetLen AS sheetLen, SheetWidth AS sheetWidth, Grammage AS grammage, WeightPerSheet AS weightPerSheet, PackQty AS packQty, PricePerPack AS pricePerPack, PricePerKg AS pricePerKg, CreditLTMonths AS creditLTMonths, CreditSurchargePctPerMonth AS creditSurchargePctPerMonth, InventoryKg AS inventoryKg, LeadTimeMonths AS leadTimeMonths FROM Materials");
    using var c2 = db.Open();
    var products = await c2.QueryAsync<Product>(@"SELECT Id AS id, Code AS code, Name AS name, Publisher AS publisher, Basket AS basket,
        TrimTitle AS trim, Pages AS pages, ColorCount AS colorCount, MarginPct AS marginPct, MarginAmt AS marginAmt,
        BudgetUnitCost AS budgetUnitCost, PdfReady AS pdfReady, Forecast AS forecast, Inventory AS inventory,
        StockPolicy AS stockPolicy, MaxBatch AS maxBatch, SalePrice AS salePrice, MaterialId AS materialId,
        HasLatFee AS hasLatFee, ForecastAuto AS forecastAuto, MaxShelfLifeYears AS maxShelfLifeYears, RoyaltyPct AS royaltyPct
        FROM Products");
    var litho = await GetContractorsWithFormLines<LithoContractor>(db,
        "SELECT Id AS id, ContractorCode AS contractorCode, Name AS name, Tech AS tech, Trim AS trim FROM LithoContractors",
        "SELECT Id AS id, LithoId AS ParentId, FormType AS formType, Rate AS rate, PagesPerForm AS pagesPerForm, MonthlyCapsJson AS MonthlyCapsJson FROM LithoFormLines");
    var printers = await GetContractorsWithFormLines<PrinterContractor>(db,
        "SELECT Id AS id, ContractorCode AS contractorCode, Printer AS printer, Machine AS machine, Tech AS tech, ColorCap AS colorCap, Waste AS waste, ScissorWidth AS scissorWidth, RequiredCutoff AS requiredCutoff, MazandaranSurchargePct AS mazandaranSurchargePct FROM PrinterContractors",
        "SELECT Id AS id, PrinterId AS ParentId, FormType AS formType, Rate AS rate, A4InForm AS a4InForm, ColorCount AS colorCount, Coefficient AS coefficient, MinRunSheets AS minRunSheets, PricePerColorBase AS pricePerColorBase, MonthlyCapA4 AS monthlyCapA4, MonthlyCapsJson AS MonthlyCapsJson FROM PrinterFormLines");
    var binderies = await GetContractorsWithFormLines<BinderyContractor>(db,
        "SELECT Id AS id, ContractorCode AS contractorCode, Name AS name, BindType AS bindType, Trim AS trim FROM BinderyContractors",
        "SELECT Id AS id, BinderyId AS ParentId, FormType AS formType, Rate AS rate, PagesPerForm AS pagesPerForm, MonthlyCapsJson AS MonthlyCapsJson FROM BinderyFormLines");
    var coverPrinters = await GetContractorsWithFormLines<CoverPrinterContractor>(db,
        "SELECT Id AS id, ContractorCode AS contractorCode, Name AS name FROM CoverPrinterContractors",
        "SELECT Id AS id, CoverId AS ParentId, FormType AS formType, ColorCount AS colorCount, Rate AS rate, PricePerColor AS pricePerColor, CoversPerForm AS coversPerForm, BaseTirage AS baseTirage, MonthlyCapsJson AS MonthlyCapsJson FROM CoverFormLines");
    using var c3 = db.Open();
    var forms = await c3.QueryAsync<FormRow>("SELECT Id AS id, Tech AS tech, Trim AS trim, A4InForm AS a4InForm, SheetType AS sheetType, FormType AS formType, PagesPerForm AS pagesPerForm FROM Forms");
    using var c4 = db.Open();
    var paperSpecs = await c4.QueryAsync<PaperSpec>("SELECT Id AS id, MaterialId AS materialId, TrimTitle AS trim, Dims AS dims, PageWeight AS pageWeight, WastePct AS wastePct, GrossConsumption AS grossConsumption, ConsumptionWithWaste AS consumptionWithWaste, SheetType AS sheetType, PagesPerSheet AS pagesPerSheet FROM PaperSpecs");
    using var c5 = db.Open();
    var settingsRows = await c5.QueryAsync<SettingItem>("SELECT SettingKey AS settingKey, SettingValue AS settingValue FROM Settings");

    return Results.Ok(new
    {
        materials,
        products,
        litho,
        printers,
        binderies,
        coverPrinters,
        forms,
        paperSpecs,
        settings = settingsRows
    });
});

if (!File.Exists(Path.Combine(app.Environment.ContentRootPath, "wwwroot", "index.html")))
    app.MapGet("/", () => Results.Redirect("/swagger"));

AuthEndpoints.Map(app);
TableEndpoints.Map(app);
VersionEndpoints.Map(app);
StateEndpoints.Map(app);
ExternalInventoryEndpoints.Map(app);   // v271 — موجودی آنلاین مواد از راهکاران/DW

await Seeder.RunAsync(app.Services, app.Configuration);

app.Run();

// ---- helper: contractor + form lines pattern shared by 4 endpoint groups ----
static async Task<List<T>> GetContractorsWithFormLines<T>(Db db, string headerSql, string linesSql) where T : class
{
    using var c = db.Open();
    var headers = (await c.QueryAsync<dynamic>(headerSql)).Cast<IDictionary<string, object>>().ToList();
    using var c2 = db.Open();
    var lines = (await c2.QueryAsync<dynamic>(linesSql)).Cast<IDictionary<string, object>>().ToList();

    var result = new List<T>();
    foreach (var h in headers)
    {
        var id = h["id"]?.ToString();
        var myLines = lines.Where(l => l["ParentId"]?.ToString() == id).Select(l =>
        {
            var flJson = System.Text.Json.JsonSerializer.Serialize(l);
            var fl = System.Text.Json.JsonSerializer.Deserialize<FormLine>(flJson, new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true })!;
            if (l.TryGetValue("MonthlyCapsJson", out var capsRaw) && capsRaw != null)
            {
                try { fl.monthlyCaps = System.Text.Json.JsonSerializer.Deserialize<List<decimal>>(capsRaw.ToString()!); } catch { }
            }
            return fl;
        }).ToList();

        var itemJson = System.Text.Json.JsonSerializer.Serialize(h);
        var item = System.Text.Json.JsonSerializer.Deserialize<T>(itemJson, new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true })!;
        typeof(T).GetProperty("formLines")!.SetValue(item, myLines);
        result.Add(item);
    }
    return result;
}

public class DateOnlyTypeHandler : SqlMapper.TypeHandler<DateOnly>
{
    public override void SetValue(IDbDataParameter parameter, DateOnly value)
    {
        parameter.DbType = DbType.Date;
        parameter.Value = value.ToDateTime(TimeOnly.MinValue);
    }

    public override DateOnly Parse(object value)
    {
        return value switch
        {
            DateTime dt => DateOnly.FromDateTime(dt),
            DateOnly d => d,
            string s => DateOnly.Parse(s),
            _ => throw new InvalidCastException($"Cannot convert {value.GetType()} to DateOnly")
        };
    }
}
