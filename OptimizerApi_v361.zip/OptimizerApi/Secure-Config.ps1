# Secure-Config.ps1  (run ONCE, as Administrator, on the server that runs the app)
#   powershell -ExecutionPolicy Bypass -File .\Secure-Config.ps1
#
# What it does:
#  1) Moves the database password out of C:\OptimizerApi\appsettings.json into a protected machine setting
#     (only Administrators/SYSTEM can read it) - the password no longer sits in a normal text file.
#  2) Creates a random token-signing key (users must log in once more after this).
#  3) Restricts the allowed web addresses (CORS) to this server's own address only.
#  4) Restarts the app and TESTS it. If the test fails, everything is put back automatically.
$ErrorActionPreference = 'Stop'
$dest = 'C:\OptimizerApi'
$port = 5050
$task = 'OptimizerApi'
$cfgPath = Join-Path $dest 'appsettings.json'
$bak = Join-Path $dest 'appsettings.json.secure-backup'

if (-not (Test-Path $cfgPath)) { throw ('Cannot find ' + $cfgPath + '. Run Install-OptimizerApi.ps1 first.') }

$raw = Get-Content $cfgPath -Raw -Encoding UTF8
$cfg = $raw | ConvertFrom-Json
$cs = $cfg.ConnectionStrings.Optimizer
if ([string]::IsNullOrWhiteSpace($cs)) { throw 'ConnectionStrings.Optimizer is empty in appsettings.json.' }
if ($cs -like '*(stored securely*') { Write-Host 'Already secured (connection string is already moved). Nothing to do.' -ForegroundColor Yellow; return }

# backup (readable by Administrators/SYSTEM only), used only if the test fails
Copy-Item $cfgPath $bak -Force
icacls $bak /inheritance:r /grant:r 'Administrators:F' 'SYSTEM:F' | Out-Null

$ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.*' } | Select-Object -First 1).IPAddress
$origins = @(('http://' + $ip + ':' + $port), ('http://localhost:' + $port), ('http://127.0.0.1:' + $port))
$extra = Read-Host 'If users also open the app with another address (for example the server name or http://10.10.7.34:5050) type it now, otherwise just press Enter'
if (-not [string]::IsNullOrWhiteSpace($extra)) { $origins += $extra.Trim().TrimEnd('/') }

$keyBytes = New-Object byte[] 48
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($keyBytes)
$jwt = [Convert]::ToBase64String($keyBytes)

try {
    [Environment]::SetEnvironmentVariable('ConnectionStrings__Optimizer', $cs, 'Machine')
    [Environment]::SetEnvironmentVariable('Jwt__Key', $jwt, 'Machine')

    $cfg.ConnectionStrings.Optimizer = '(stored securely in the machine settings - do not put the password here)'
    if (-not $cfg.PSObject.Properties['Cors']) { $cfg | Add-Member -NotePropertyName Cors -NotePropertyValue ([pscustomobject]@{ AllowedOrigins = @() }) }
    $cfg.Cors.AllowedOrigins = @($origins)
    $json = $cfg | ConvertTo-Json -Depth 10
    [IO.File]::WriteAllText($cfgPath, $json, (New-Object Text.UTF8Encoding($false)))

    Write-Host 'Restarting the app...'
    Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
    Get-Process OptimizerApi -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-CimInstance Win32_Process -Filter "Name='dotnet.exe'" | Where-Object { $_.CommandLine -like '*OptimizerApi*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
    Start-Sleep -Seconds 3
    # Task Scheduler gives new processes a fresh copy of machine settings only after the task is registered again
    $t = Get-ScheduledTask -TaskName $task
    Unregister-ScheduledTask -TaskName $task -Confirm:$false
    Register-ScheduledTask -InputObject $t | Out-Null
    Start-ScheduledTask -TaskName $task
    Start-Sleep -Seconds 12

    # TEST: a wrong login must answer "401 wrong user/password" (this proves the database connection works)
    $code = 0
    try {
        Invoke-WebRequest -UseBasicParsing -Method Post -ContentType 'application/json' -Body '{"email":"zz-test","password":"zz-test"}' ('http://localhost:' + $port + '/api/auth/login') -TimeoutSec 20 | Out-Null
    } catch { if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode } }
    if ($code -ne 401) { throw ('Test failed (answer code ' + $code + '), the app cannot reach the database with the new settings.') }

    Remove-Item $bak -Force
    Write-Host 'DONE. The database password is no longer in appsettings.json, and CORS is restricted to:' -ForegroundColor Green
    $origins | ForEach-Object { Write-Host ('   ' + $_) -ForegroundColor Green }
    Write-Host 'All users must log in once more (new signing key). Please also blank the password in the appsettings.json copy inside the project folder / zip.' -ForegroundColor Cyan
}
catch {
    Write-Host ('PROBLEM: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Putting the old settings back...' -ForegroundColor Yellow
    [Environment]::SetEnvironmentVariable('ConnectionStrings__Optimizer', $null, 'Machine')
    [Environment]::SetEnvironmentVariable('Jwt__Key', $null, 'Machine')
    if (Test-Path $bak) { Copy-Item $bak $cfgPath -Force; Remove-Item $bak -Force }
    Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
    Get-Process OptimizerApi -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-CimInstance Win32_Process -Filter "Name='dotnet.exe'" | Where-Object { $_.CommandLine -like '*OptimizerApi*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
    Start-Sleep -Seconds 2
    Start-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
    Write-Host 'Old settings restored and the app restarted. Send the red message above to the developer.' -ForegroundColor Yellow
}
