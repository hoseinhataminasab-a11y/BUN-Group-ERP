# Permanent install of OptimizerApi (run once, as Administrator, inside the project folder).
#   powershell -ExecutionPolicy Bypass -File .\Install-OptimizerApi.ps1
# Requires: appsettings.json in this folder, and .NET 8 SDK installed.
$ErrorActionPreference = 'Stop'
$dest = 'C:\OptimizerApi'
$port = 5050
$task = 'OptimizerApi'

if (-not (Test-Path .\appsettings.json)) { throw 'appsettings.json not found in this folder. Copy your working appsettings.json here first.' }
if (-not (Test-Path .\Program.cs)) { throw 'Program.cs not found. Run this script from the project folder.' }

Write-Host '1) Building new version first (the running app is NOT touched yet)...'
$tmp = 'C:\OptimizerApi_build'
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
dotnet publish -c Release -o $tmp
if ($LASTEXITCODE -ne 0) { throw 'Build failed. The old running version was left untouched. Send the error text above to the developer.' }

Write-Host '2) Stopping previous version (if any) and copying the new one...'
if (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $task -Confirm:$false
}
# v272 — بعضی پروسه‌ها همزمان با توقف Task خودشان بسته می‌شوند؛ اگر پروسه دیگر وجود نداشت خطا نیست.
Get-Process OptimizerApi -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process -Filter "Name='dotnet.exe'" | Where-Object { $_.CommandLine -like '*OptimizerApi.dll*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 2
if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest | Out-Null }
robocopy $tmp $dest /E /XF log.txt /NFL /NDL /NJH /NJS | Out-Null
if ($LASTEXITCODE -ge 8) { throw 'Copy to C:\OptimizerApi failed.' }
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

Write-Host '3) Registering auto-start at boot...'
$cmd = '/c cd /d ' + $dest + ' && dotnet OptimizerApi.dll --urls http://0.0.0.0:' + $port + ' >> ' + $dest + '\log.txt 2>&1'
$action    = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument $cmd
$trigger   = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName $task -Action $action -Trigger $trigger -Principal $principal -Settings $settings | Out-Null

Write-Host "4) Opening firewall port $port ..."
$rule = 'OptimizerApi ' + $port
if (-not (Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName $rule -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow | Out-Null
}

Write-Host '5) Starting the app...'
Start-ScheduledTask -TaskName $task
Start-Sleep -Seconds 10
try {
    $r = Invoke-WebRequest -UseBasicParsing ('http://localhost:' + $port + '/') -TimeoutSec 20
    Write-Host ('App is UP (HTTP ' + $r.StatusCode + ').') -ForegroundColor Green
} catch {
    Write-Host 'No response yet. Check C:\OptimizerApi\log.txt' -ForegroundColor Yellow
}
$ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.*' } | Select-Object -First 1).IPAddress
Write-Host ''
Write-Host ('App address for all users:  http://' + $ip + ':' + $port + '/') -ForegroundColor Cyan
Write-Host 'Future updates: just replace C:\OptimizerApi\wwwroot\index.html (no restart needed).'
