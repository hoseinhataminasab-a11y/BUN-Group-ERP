using System.Text.RegularExpressions;
using Dapper;
using Microsoft.Data.SqlClient;
using OptimizerApi.Services;

namespace OptimizerApi.Endpoints;

// v271 — موجودی آنلاین مواد از راهکاران / انبار دادهٔ BI (فقط خواندنی).
// اتصال در appsettings.json → بخش "ExternalInventory": { "ConnectionString": "..." } تنظیم می‌شود
// (بهتر است با یک کاربر SQL فقط‌خواندنی). نام جدول/ویو و ستون‌ها از داخل برنامه انتخاب می‌شوند؛
// سرور قبل از اجرا وجودشان را در INFORMATION_SCHEMA همان پایگاه داده بررسی می‌کند و نام‌ها را
// داخل [] می‌گذارد — هیچ متن SQL آزادی از مرورگر اجرا نمی‌شود.
//   GET  /api/external/inventory/status                 آیا اتصال تنظیم شده؟
//   GET  /api/external/inventory/columns?table=dbo.X    ستون‌ها + ۲۰ ردیف نمونه
//   POST /api/external/inventory/pull                   {table, codeCol, nameCol?, warehouseCol?, qtyCol, unitCol?}
public static class ExternalInventoryEndpoints
{
    private static readonly Regex NameRx = new(@"^[\p{L}\p{N}_ \-\.]{1,128}$", RegexOptions.Compiled);

    public class PullRequest
    {
        public string? Table { get; set; }
        public string? CodeCol { get; set; }
        public string? NameCol { get; set; }
        public string? WarehouseCol { get; set; }
        public string? QtyCol { get; set; }
        public string? UnitCol { get; set; }
    }

    private class ColRow
    {
        public string Name { get; set; } = "";
        public string Type { get; set; } = "";
    }

    private static string ConnStr(IConfiguration cfg)
    {
        var cs = cfg["ExternalInventory:ConnectionString"];
        if (string.IsNullOrWhiteSpace(cs))
            throw new ApiException(503, "اتصال به راهکاران/DW هنوز در سرور تنظیم نشده است (appsettings.json ← ExternalInventory:ConnectionString).");
        return cs;
    }

    private static CurrentUser NeedRole(HttpContext ctx)
    {
        var u = Ctx.User(ctx);
        if (!(u.IsAdmin || u.Role == "prod")) throw new ApiException(403, "فقط مدیر کل و کارشناس تولید به موجودی آنلاین دسترسی دارند.");
        return u;
    }

    // "dbo.vw_Stock" یا "vw_Stock" → (schema, name)
    private static (string schema, string name) SplitTable(string? table)
    {
        var t = (table ?? "").Trim().Replace("[", "").Replace("]", "");
        if (t.Length == 0) throw new ApiException(400, "نام جدول یا ویو را وارد کنید.");
        var parts = t.Split('.');
        if (parts.Length > 2) throw new ApiException(400, "نام جدول باید به شکل schema.name یا فقط name باشد.");
        var schema = parts.Length == 2 ? parts[0].Trim() : "dbo";
        var name = parts[^1].Trim();
        if (!NameRx.IsMatch(schema) || !NameRx.IsMatch(name)) throw new ApiException(400, "نام جدول نامعتبر است.");
        return (schema, name);
    }

    private static string Q(string ident) => "[" + ident.Replace("]", "]]") + "]";

    private static async Task<List<ColRow>> Columns(SqlConnection c, string schema, string name)
    {
        var cols = (await c.QueryAsync<ColRow>(
            @"SELECT COLUMN_NAME AS Name, DATA_TYPE AS Type FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA = @s AND TABLE_NAME = @n ORDER BY ORDINAL_POSITION",
            new { s = schema, n = name }, commandTimeout: 30)).ToList();
        if (cols.Count == 0) throw new ApiException(404, $"جدول یا ویوی «{schema}.{name}» در پایگاه دادهٔ مقصد پیدا نشد (یا کاربر اتصال به آن دسترسی ندارد).");
        return cols;
    }

    private static string? Col(List<ColRow> cols, string? wanted, bool required, string label)
    {
        if (string.IsNullOrWhiteSpace(wanted))
        {
            if (required) throw new ApiException(400, $"ستون «{label}» انتخاب نشده است.");
            return null;
        }
        var hit = cols.FirstOrDefault(x => string.Equals(x.Name, wanted.Trim(), StringComparison.OrdinalIgnoreCase));
        if (hit == null) throw new ApiException(400, $"ستون «{wanted}» در جدول مقصد وجود ندارد.");
        return hit.Name;
    }

    private static Dictionary<string, object?> ToDict(object row) =>
        ((IDictionary<string, object>)row).ToDictionary(k => k.Key, v => (object?)v.Value);

    public static void Map(WebApplication app)
    {
        app.MapGet("/api/external/inventory/status", async (HttpContext ctx, IConfiguration cfg) =>
        {
            NeedRole(ctx);
            var cs = cfg["ExternalInventory:ConnectionString"];
            if (string.IsNullOrWhiteSpace(cs)) return Results.Ok(new { configured = false });
            try
            {
                var b = new SqlConnectionStringBuilder(cs);
                using var c = new SqlConnection(cs);
                await c.OpenAsync();
                return Results.Ok(new { configured = true, reachable = true, server = b.DataSource, database = b.InitialCatalog });
            }
            catch (Exception ex)
            {
                return Results.Ok(new { configured = true, reachable = false, error = ex.Message });
            }
        });

        app.MapGet("/api/external/inventory/columns", async (HttpContext ctx, IConfiguration cfg, string? table) =>
        {
            NeedRole(ctx);
            var (schema, name) = SplitTable(table);
            using var c = new SqlConnection(ConnStr(cfg));
            var cols = await Columns(c, schema, name);
            var sample = (await c.QueryAsync($"SELECT TOP 20 * FROM {Q(schema)}.{Q(name)}", commandTimeout: 60))
                .Select(r => ToDict(r)).ToList();
            return Results.Ok(new { table = schema + "." + name, columns = cols.Select(x => new { name = x.Name, type = x.Type }), sample });
        });

        app.MapPost("/api/external/inventory/pull", async (HttpContext ctx, IConfiguration cfg, PullRequest req) =>
        {
            NeedRole(ctx);
            var (schema, name) = SplitTable(req.Table);
            using var c = new SqlConnection(ConnStr(cfg));
            var cols = await Columns(c, schema, name);
            var code = Col(cols, req.CodeCol, true, "کد کالا")!;
            var qty = Col(cols, req.QtyCol, true, "مقدار")!;
            var nm = Col(cols, req.NameCol, false, "نام کالا");
            var wh = Col(cols, req.WarehouseCol, false, "انبار");
            var unit = Col(cols, req.UnitCol, false, "واحد");
            var sql = "SELECT CAST(" + Q(code) + " AS nvarchar(100)) AS code, "
                    + (nm != null ? "CAST(" + Q(nm) + " AS nvarchar(400))" : "CAST(NULL AS nvarchar(400))") + " AS name, "
                    + (wh != null ? "CAST(" + Q(wh) + " AS nvarchar(200))" : "CAST(NULL AS nvarchar(200))") + " AS warehouse, "
                    + "TRY_CAST(" + Q(qty) + " AS decimal(38,6)) AS qty, "
                    + (unit != null ? "CAST(" + Q(unit) + " AS nvarchar(50))" : "CAST(NULL AS nvarchar(50))") + " AS unit "
                    + "FROM " + Q(schema) + "." + Q(name);
            var rows = (await c.QueryAsync(sql, commandTimeout: 120)).Select(r => ToDict(r)).ToList();
            return Results.Ok(new { table = schema + "." + name, count = rows.Count, at = DateTime.UtcNow, rows });
        });
    }
}
