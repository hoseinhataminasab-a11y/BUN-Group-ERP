using System.Text.Json;
using Dapper;
using OptimizerApi.Data;
using OptimizerApi.Services;

namespace OptimizerApi.Endpoints;

// «ذخیرهٔ ورژن» برای سه خروجی: برنامه تولید، برنامه فروش، اکچوال تولید.
//   POST   /api/versions/{kind}            ذخیرهٔ نسخهٔ جدید   (kind = prodplan | salesplan | prodactual)
//   GET    /api/versions?kind=&year=       فهرست نسخه‌ها (بدون حجم سنگین)
//   GET    /api/versions/approved?kind=&year=   آخرین نسخهٔ مصوب
//   GET    /api/versions/{id}              باز کردن نسخه (هدر + payload کامل برای برگرداندن به برنامه)
//   GET    /api/versions/{id}/rows         ردیف‌های جدولی نسخه (برای گزارش/BI)
//   POST   /api/versions/{id}/approve      تأیید نسخه (فقط مدیر کل؛ نسخهٔ مصوب قبلی همان سال/نوع از مصوب درمی‌آید)
//   DELETE /api/versions/{id}              حذف نسخه (فقط مدیر کل، فقط نامصوب و بدون وابستگی)
public static class VersionEndpoints
{
    private static string? KindOf(string s) => s.ToLowerInvariant().Replace("-", "").Replace("_", "") switch
    {
        "prodplan" => "PROD_PLAN",
        "salesplan" => "SALES_PLAN",
        "prodactual" => "PROD_ACTUAL",
        _ => null
    };

    private static string[] SaveRoles(string kind) =>
        kind == "SALES_PLAN" ? new[] { "admin", "sales" } : new[] { "admin", "prod" };

    private static string? Str(JsonElement b, string name) =>
        b.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private static int? Int(JsonElement b, string name)
    {
        if (!b.TryGetProperty(name, out var v)) return null;
        if (v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var i)) return i;
        if (v.ValueKind == JsonValueKind.String && int.TryParse(v.GetString(), out var j)) return j;
        return null;
    }

    private static string? Raw(JsonElement b, string name) =>
        b.TryGetProperty(name, out var v) && v.ValueKind != JsonValueKind.Null && v.ValueKind != JsonValueKind.Undefined
            ? (v.ValueKind == JsonValueKind.String ? v.GetString() : v.GetRawText())
            : null;

    private static List<JsonElement> Arr(JsonElement b, string name)
    {
        if (b.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.Array) return v.EnumerateArray().ToList();
        return new List<JsonElement>();
    }

    private const string HeaderCols = @"
        Id AS id, Kind AS kind, FiscalYear AS fiscalYear, VersionNo AS versionNo, Label AS label, PlanType AS planType,
        Engine AS engine, Scenario AS scenario, Month AS month, BasePlanVersionId AS basePlanVersionId,
        IsApproved AS isApproved, Status AS status, KpiJson AS kpiJson, Notes AS notes, CreatedAt AS createdAt,
        CreatedBy AS createdBy, ApprovedAt AS approvedAt, ApprovedBy AS approvedBy";

    public static void Map(WebApplication app)
    {
        // ---------------- ذخیرهٔ نسخهٔ جدید ----------------
        app.MapPost("/api/versions/{kind}", async (string kind, JsonElement body, HttpContext ctx, Db db, SchemaCache sc, AuditService audit) =>
        {
            var k = KindOf(kind) ?? throw new ApiException(400, "نوع نسخه باید prodplan یا salesplan یا prodactual باشد.");
            var u = Ctx.Require(ctx, SaveRoles(k));
            if (body.ValueKind != JsonValueKind.Object) throw new ApiException(400, "بدنهٔ درخواست باید یک شیء JSON باشد.");

            var year = Int(body, "fiscalYear") ?? throw new ApiException(400, "fiscalYear (سال مالی) لازم است.");
            if (year < 1000 || year > 2100) throw new ApiException(400, "fiscalYear نامعتبر است.");
            var planType = Str(body, "planType");
            if (planType != null && planType != "budget" && planType != "forecast") throw new ApiException(400, "planType باید budget یا forecast باشد.");
            if (k == "PROD_ACTUAL") planType = null;
            var month = Int(body, "month");
            if (month.HasValue && (month < 1 || month > 12)) throw new ApiException(400, "month باید ۱ تا ۱۲ باشد.");
            var baseId = Int(body, "basePlanVersionId");

            using var c = db.Open();
            await c.OpenAsync();
            using var tx = c.BeginTransaction();

            if (baseId.HasValue)
            {
                var ok = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM DataVersions WHERE Id = @id AND Kind = 'PROD_PLAN'", new { id = baseId.Value }, tx);
                if (ok == 0) throw new ApiException(400, "نسخهٔ برنامه تولیدِ مبنا (basePlanVersionId) پیدا نشد.");
            }

            var next = await c.ExecuteScalarAsync<int>(
                "SELECT ISNULL(MAX(VersionNo), 0) + 1 FROM DataVersions WITH (UPDLOCK, HOLDLOCK) WHERE Kind = @k AND FiscalYear = @y",
                new { k, y = year }, tx);
            var label = Str(body, "label");
            if (string.IsNullOrWhiteSpace(label)) label = "نسخه " + next;

            var id = await c.ExecuteScalarAsync<int>(@"
                INSERT INTO DataVersions (Kind, FiscalYear, VersionNo, Label, PlanType, Engine, Scenario, Month, BasePlanVersionId,
                                          KpiJson, SettingsSnapshotJson, PayloadJson, Notes, CreatedBy)
                OUTPUT INSERTED.Id
                VALUES (@k, @y, @no, @label, @pt, @eng, @sc, @m, @bid, @kpi, @snap, @payload, @notes, @by)",
                new
                {
                    k, y = year, no = next, label, pt = planType, eng = Str(body, "engine"), sc = Str(body, "scenario"),
                    m = month, bid = baseId, kpi = Raw(body, "kpi"), snap = Raw(body, "settingsSnapshot"),
                    payload = Raw(body, "payload"), notes = Str(body, "notes"), by = u.Email
                }, tx);

            var consts = new Dictionary<string, object?> { ["VersionId"] = id };
            var counts = new Dictionary<string, int>();

            async Task Put(string tableName, List<JsonElement> rows)
            {
                if (rows.Count == 0) return;
                var t = await sc.FindAsync(tableName) ?? throw new ApiException(500, $"جدول {tableName} در دیتابیس نیست (اسکریپت فاز ۳ اجرا شده؟).");
                counts[tableName] = await Conv.BulkInsertAsync(c, tx, t, rows, consts);
            }

            switch (k)
            {
                case "PROD_PLAN":
                    await Put("ProdPlanVersionRows", Arr(body, "rows"));
                    await Put("ProdPlanVersionUnmet", Arr(body, "unmet"));
                    await Put("ProdPlanVersionPayments", Arr(body, "payments"));
                    break;
                case "SALES_PLAN":
                    await Put("SalesPlanVersionRows", Arr(body, "rows"));
                    if (body.TryGetProperty("meta", out var meta) && meta.ValueKind == JsonValueKind.Object)
                        await Put("SalesPlanVersionMeta", new List<JsonElement> { meta });
                    break;
                case "PROD_ACTUAL":
                    await Put("ProdActualVersionRows", Arr(body, "rows"));
                    break;
            }

            tx.Commit();
            await audit.LogAsync(u, "SAVE_VERSION", "DataVersions", id.ToString(),
                $"{k} سال {year} نسخه {next} «{label}» " + string.Join(", ", counts.Select(x => x.Key + "=" + x.Value)));
            return Results.Ok(new { id, kind = k, fiscalYear = year, versionNo = next, label, rows = counts });
        });

        // ---------------- فهرست ----------------
        app.MapGet("/api/versions", async (HttpContext ctx, Db db) =>
        {
            string? kindRaw = ctx.Request.Query["kind"];
            string? k = string.IsNullOrEmpty(kindRaw) ? null : (KindOf(kindRaw) ?? throw new ApiException(400, "kind نامعتبر است."));
            int? year = int.TryParse(ctx.Request.Query["year"], out var y) ? y : null;
            using var c = db.Open();
            var rows = await c.QueryAsync($@"
                SELECT {HeaderCols}, DATALENGTH(PayloadJson) AS payloadBytes
                FROM DataVersions
                WHERE (@k IS NULL OR Kind = @k) AND (@y IS NULL OR FiscalYear = @y)
                ORDER BY FiscalYear DESC, Kind, VersionNo DESC", new { k, y = year });
            return Results.Ok(Conv.ToDicts(rows));
        });

        app.MapGet("/api/versions/approved", async (HttpContext ctx, Db db) =>
        {
            string? kindRaw = ctx.Request.Query["kind"];
            var k = KindOf(kindRaw ?? "") ?? throw new ApiException(400, "kind لازم است.");
            int? year = int.TryParse(ctx.Request.Query["year"], out var y) ? y : null;
            using var c = db.Open();
            var rows = await c.QueryAsync($@"
                SELECT TOP 1 {HeaderCols} FROM DataVersions
                WHERE Kind = @k AND IsApproved = 1 AND (@y IS NULL OR FiscalYear = @y)
                ORDER BY FiscalYear DESC, VersionNo DESC", new { k, y = year });
            var list = Conv.ToDicts(rows);
            if (list.Count == 0) throw new ApiException(404, "نسخهٔ مصوبی پیدا نشد.");
            return Results.Ok(list[0]);
        });

        // ---------------- باز کردن ----------------
        app.MapGet("/api/versions/{id:int}", async (int id, Db db) =>
        {
            using var c = db.Open();
            var rows = await c.QueryAsync($"SELECT {HeaderCols}, PayloadJson AS payloadJson, SettingsSnapshotJson AS settingsSnapshotJson FROM DataVersions WHERE Id = @id", new { id });
            var list = Conv.ToDicts(rows);
            if (list.Count == 0) throw new ApiException(404, "نسخه پیدا نشد.");
            var h = list[0];
            JsonElement? payload = null, snap = null, kpi = null;
            if (h["payloadJson"] is string ps && ps.Length > 0) payload = JsonDocument.Parse(ps).RootElement.Clone();
            if (h["settingsSnapshotJson"] is string ss && ss.Length > 0) snap = JsonDocument.Parse(ss).RootElement.Clone();
            if (h["kpiJson"] is string ks && ks.Length > 0) kpi = JsonDocument.Parse(ks).RootElement.Clone();
            h.Remove("payloadJson"); h.Remove("settingsSnapshotJson"); h.Remove("kpiJson");
            return Results.Ok(new { header = h, kpi, settingsSnapshot = snap, payload });
        });

        app.MapGet("/api/versions/{id:int}/rows", async (int id, Db db) =>
        {
            using var c = db.Open();
            var kind = await c.ExecuteScalarAsync<string?>("SELECT Kind FROM DataVersions WHERE Id = @id", new { id });
            if (kind == null) throw new ApiException(404, "نسخه پیدا نشد.");
            string tbl = kind switch { "PROD_PLAN" => "ProdPlanVersionRows", "SALES_PLAN" => "SalesPlanVersionRows", _ => "ProdActualVersionRows" };
            var rows = await c.QueryAsync($"SELECT * FROM [{tbl}] WHERE VersionId = @id ORDER BY Id", new { id });
            return Results.Ok(Conv.ToDicts(rows));
        });

        // ---------------- تأیید ----------------
        app.MapPost("/api/versions/{id:int}/approve", async (int id, HttpContext ctx, Db db, AuditService audit) =>
        {
            var u = Ctx.Require(ctx, "admin");
            using var c = db.Open();
            await c.OpenAsync();
            using var tx = c.BeginTransaction();
            var hdr = await c.QuerySingleOrDefaultAsync<VersionHead>("SELECT Kind, FiscalYear FROM DataVersions WHERE Id = @id", new { id }, tx);
            if (hdr == null) throw new ApiException(404, "نسخه پیدا نشد.");
            await c.ExecuteAsync(
                "UPDATE DataVersions SET IsApproved = 0, Status = 'Saved', ApprovedAt = NULL, ApprovedBy = NULL WHERE Kind = @k AND FiscalYear = @y AND IsApproved = 1 AND Id <> @id",
                new { k = hdr.Kind, y = hdr.FiscalYear, id }, tx);
            await c.ExecuteAsync(
                "UPDATE DataVersions SET IsApproved = 1, Status = 'Approved', ApprovedAt = SYSUTCDATETIME(), ApprovedBy = @by WHERE Id = @id",
                new { by = u.Email, id }, tx);
            tx.Commit();
            await audit.LogAsync(u, "APPROVE_VERSION", "DataVersions", id.ToString(), hdr.Kind + " " + hdr.FiscalYear);
            return Results.Ok(new { approved = id });
        });

        // ---------------- حذف ----------------
        app.MapDelete("/api/versions/{id:int}", async (int id, HttpContext ctx, Db db, AuditService audit) =>
        {
            var u = Ctx.Require(ctx, "admin");
            using var c = db.Open();
            var hdr = await c.QuerySingleOrDefaultAsync<VersionHead>("SELECT Kind, FiscalYear, IsApproved FROM DataVersions WHERE Id = @id", new { id });
            if (hdr == null) throw new ApiException(404, "نسخه پیدا نشد.");
            if (hdr.IsApproved) throw new ApiException(409, "نسخهٔ مصوب حذف نمی‌شود. ابتدا نسخهٔ دیگری را مصوب کنید.");
            var used = await c.ExecuteScalarAsync<int>(
                "SELECT (SELECT COUNT(1) FROM DataVersions WHERE BasePlanVersionId = @id) + (SELECT COUNT(1) FROM ProdActualsLive WHERE PlanVersionId = @id)",
                new { id });
            if (used > 0) throw new ApiException(409, "این نسخه مبنای اکچوال‌ها (یا نسخهٔ اکچوال) است و حذف نمی‌شود.");
            var n = await c.ExecuteAsync("DELETE FROM DataVersions WHERE Id = @id", new { id }, null, 300);
            await audit.LogAsync(u, "DELETE_VERSION", "DataVersions", id.ToString(), hdr.Kind + " " + hdr.FiscalYear);
            return Results.Ok(new { deleted = n });
        });
    }

    private class VersionHead
    {
        public string Kind { get; set; } = "";
        public int FiscalYear { get; set; }
        public bool IsApproved { get; set; }
    }
}
