using System.Text.Json;
using Dapper;
using OptimizerApi.Data;
using OptimizerApi.Services;

namespace OptimizerApi.Endpoints;

public record LoginReq(string? email, string? password);
public record ChangePasswordReq(string? oldPassword, string? newPassword);
public record NewUserReq(string? email, string? fullName, string? roleId, string? password);
public record UpdateUserReq(string? fullName, string? roleId, bool? isActive);
public record ResetPasswordReq(string? newPassword);
public record RoleSyncReq(string? id, string? name);
public record PermissionReq(string? scope, string? targetKey, string? access, string? rowFilterJson);

public static class AuthEndpoints
{
    private class UserRow
    {
        public string Id { get; set; } = "";
        public string Email { get; set; } = "";
        public string? FullName { get; set; }
        public string? RoleId { get; set; }
        public string? RoleName { get; set; }
        public bool IsActive { get; set; }
        public string? PasswordHash { get; set; }
        public bool MustChangePassword { get; set; }
        public int FailedLogins { get; set; }
        public DateTime? LockedUntil { get; set; }
    }

    private const string UserSql = @"
        SELECT u.Id, u.Email, u.FullName, u.RoleId, r.Name AS RoleName, u.IsActive, u.PasswordHash,
               u.MustChangePassword, u.FailedLogins, u.LockedUntil
        FROM AppUsers u LEFT JOIN AppRoles r ON r.Id = u.RoleId ";

    private static void CheckPassword(string? pw)
    {
        if (string.IsNullOrEmpty(pw) || pw.Length < 8)
            throw new ApiException(400, "رمز باید حداقل ۸ نویسه باشد.");
    }

    private static object UserDto(UserRow u) => new
    {
        id = u.Id, email = u.Email, fullName = u.FullName, roleId = u.RoleId, roleName = u.RoleName,
        mustChangePassword = u.MustChangePassword
    };

    public static void Map(WebApplication app)
    {
        // ---------------- ورود ----------------
        app.MapPost("/api/auth/login", async (LoginReq req, Db db, JwtService jwt, AuditService audit) =>
        {
            var email = (req.email ?? "").Trim();
            var pw = req.password ?? "";
            if (email.Length == 0 || pw.Length == 0) throw new ApiException(400, "نام کاربری و رمز را وارد کنید.");

            using var c = db.Open();
            var u = await c.QuerySingleOrDefaultAsync<UserRow>(UserSql + "WHERE u.Email = @e", new { e = email });
            const string bad = "نام کاربری یا رمز اشتباه است.";
            if (u == null) { await audit.LogAsync(null, "LOGIN_FAIL", "AppUsers", email, "کاربر ناشناس"); throw new ApiException(401, bad); }
            if (!u.IsActive) throw new ApiException(403, "این کاربر غیرفعال شده است.");
            if (u.LockedUntil.HasValue && u.LockedUntil.Value > DateTime.UtcNow)
                throw new ApiException(423, "به‌خاطر چند بار رمز اشتباه، ورود تا چند دقیقه قفل شده است. بعداً دوباره تلاش کنید.");

            if (!PasswordHasher.Verify(pw, u.PasswordHash))
            {
                var fails = u.FailedLogins + 1;
                if (fails >= 5)
                    await c.ExecuteAsync("UPDATE AppUsers SET FailedLogins = 0, LockedUntil = @t WHERE Id = @id",
                        new { t = DateTime.UtcNow.AddMinutes(15), id = u.Id });
                else
                    await c.ExecuteAsync("UPDATE AppUsers SET FailedLogins = @f WHERE Id = @id", new { f = fails, id = u.Id });
                await audit.LogAsync(new CurrentUser(u.Id, u.Email, u.FullName ?? u.Email, u.RoleId ?? ""), "LOGIN_FAIL", "AppUsers", u.Id);
                throw new ApiException(401, bad);
            }

            await c.ExecuteAsync("UPDATE AppUsers SET FailedLogins = 0, LockedUntil = NULL, LastLoginAt = SYSUTCDATETIME() WHERE Id = @id", new { id = u.Id });
            var cu = new CurrentUser(u.Id, u.Email, u.FullName ?? u.Email, u.RoleId ?? "none");
            var (token, exp) = jwt.Create(cu);
            await audit.LogAsync(cu, "LOGIN", "AppUsers", u.Id);
            return Results.Ok(new { token, expiresAt = exp, user = UserDto(u) });
        });

        app.MapGet("/api/auth/me", async (HttpContext ctx, Db db) =>
        {
            var cu = Ctx.User(ctx);
            using var c = db.Open();
            var u = await c.QuerySingleOrDefaultAsync<UserRow>(UserSql + "WHERE u.Id = @id", new { id = cu.Id });
            if (u == null || !u.IsActive) throw new ApiException(401, "کاربر پیدا نشد یا غیرفعال است.");
            return Results.Ok(UserDto(u));
        });

        app.MapPost("/api/auth/change-password", async (ChangePasswordReq req, HttpContext ctx, Db db, AuditService audit) =>
        {
            var cu = Ctx.User(ctx);
            CheckPassword(req.newPassword);
            using var c = db.Open();
            var u = await c.QuerySingleOrDefaultAsync<UserRow>(UserSql + "WHERE u.Id = @id", new { id = cu.Id });
            if (u == null || !PasswordHasher.Verify(req.oldPassword ?? "", u.PasswordHash))
                throw new ApiException(400, "رمز فعلی درست نیست.");
            if (req.newPassword == req.oldPassword) throw new ApiException(400, "رمز جدید باید با رمز قبلی فرق کند.");
            await c.ExecuteAsync("UPDATE AppUsers SET PasswordHash = @h, MustChangePassword = 0 WHERE Id = @id",
                new { h = PasswordHasher.Hash(req.newPassword!), id = cu.Id });
            await audit.LogAsync(cu, "CHANGE_PASSWORD", "AppUsers", cu.Id);
            return Results.Ok(new { ok = true });
        });

        // ---------------- مدیریت کاربران (فقط مدیر کل) ----------------
        app.MapGet("/api/users", async (HttpContext ctx, Db db) =>
        {
            Ctx.Require(ctx, "admin");
            using var c = db.Open();
            var rows = await c.QueryAsync(@"
                SELECT u.Id AS id, u.Email AS email, u.FullName AS fullName, u.RoleId AS roleId, r.Name AS roleName,
                       u.IsActive AS isActive, u.MustChangePassword AS mustChangePassword, u.LastLoginAt AS lastLoginAt,
                       u.CreatedAt AS createdAt
                FROM AppUsers u LEFT JOIN AppRoles r ON r.Id = u.RoleId ORDER BY u.CreatedAt");
            return Results.Ok(Conv.ToDicts(rows));
        });

        app.MapPost("/api/users", async (NewUserReq req, HttpContext ctx, Db db, AuditService audit) =>
        {
            var cu = Ctx.Require(ctx, "admin");
            var email = (req.email ?? "").Trim();
            if (email.Length < 2) throw new ApiException(400, "نام کاربری (ایمیل) را وارد کنید.");
            CheckPassword(req.password);
            using var c = db.Open();
            var roleOk = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppRoles WHERE Id = @r", new { r = req.roleId });
            if (roleOk == 0) throw new ApiException(400, "نقش انتخاب‌شده وجود ندارد.");
            var exists = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppUsers WHERE Email = @e", new { e = email });
            if (exists > 0) throw new ApiException(409, "این نام کاربری قبلاً ثبت شده است.");
            var id = "u" + Guid.NewGuid().ToString("N").Substring(0, 10);
            await c.ExecuteAsync(
                "INSERT INTO AppUsers (Id, Email, FullName, RoleId, IsActive, PasswordHash, MustChangePassword) VALUES (@id, @e, @n, @r, 1, @h, 1)",
                new { id, e = email, n = req.fullName, r = req.roleId, h = PasswordHasher.Hash(req.password!) });
            await audit.LogAsync(cu, "USER_CREATE", "AppUsers", id, email + " / " + req.roleId);
            return Results.Ok(new { id });
        });

        app.MapPut("/api/users/{id}", async (string id, UpdateUserReq req, HttpContext ctx, Db db, AuditService audit) =>
        {
            var cu = Ctx.Require(ctx, "admin");
            using var c = db.Open();
            if (req.roleId != null)
            {
                var roleOk = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppRoles WHERE Id = @r", new { r = req.roleId });
                if (roleOk == 0) throw new ApiException(400, "نقش انتخاب‌شده وجود ندارد.");
            }
            // جلوگیری از قفل شدن سیستم: آخرین مدیر فعال را نمی‌شود غیرفعال یا تنزل داد
            var willLoseAdmin = (req.isActive == false) || (req.roleId != null && req.roleId != "admin");
            if (willLoseAdmin)
            {
                var otherAdmins = await c.ExecuteScalarAsync<int>(
                    "SELECT COUNT(1) FROM AppUsers WHERE RoleId = 'admin' AND IsActive = 1 AND Id <> @id", new { id });
                var isAdminNow = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppUsers WHERE Id = @id AND RoleId = 'admin'", new { id });
                if (isAdminNow > 0 && otherAdmins == 0) throw new ApiException(400, "حداقل یک مدیر کل فعال باید بماند.");
            }
            var n = await c.ExecuteAsync(@"
                UPDATE AppUsers SET FullName = COALESCE(@n, FullName), RoleId = COALESCE(@r, RoleId), IsActive = COALESCE(@a, IsActive)
                WHERE Id = @id", new { n = req.fullName, r = req.roleId, a = req.isActive, id });
            if (n == 0) throw new ApiException(404, "کاربر پیدا نشد.");
            await audit.LogAsync(cu, "USER_UPDATE", "AppUsers", id, JsonSerializer.Serialize(req));
            return Results.Ok(new { updated = n });
        });

        app.MapPost("/api/users/{id}/reset-password", async (string id, ResetPasswordReq req, HttpContext ctx, Db db, AuditService audit) =>
        {
            var cu = Ctx.Require(ctx, "admin");
            CheckPassword(req.newPassword);
            using var c = db.Open();
            var n = await c.ExecuteAsync(
                "UPDATE AppUsers SET PasswordHash = @h, MustChangePassword = 1, FailedLogins = 0, LockedUntil = NULL WHERE Id = @id",
                new { h = PasswordHasher.Hash(req.newPassword!), id });
            if (n == 0) throw new ApiException(404, "کاربر پیدا نشد.");
            await audit.LogAsync(cu, "USER_RESET_PW", "AppUsers", id);
            return Results.Ok(new { ok = true });
        });

        // ---------------- نقش‌ها و دسترسی‌ها ----------------
        app.MapGet("/api/roles", async (Db db) =>
        {
            using var c = db.Open();
            var rows = await c.QueryAsync("SELECT Id AS id, Name AS name, Description AS description FROM AppRoles ORDER BY Name");
            return Results.Ok(Conv.ToDicts(rows));
        });

        // همگام‌سازی نقش‌های ساخته‌شده در «دسترسی تفصیلی» برنامه با جدول AppRoles (تا بشود به کاربر داد)
        app.MapPost("/api/roles/sync", async (List<RoleSyncReq> items, HttpContext ctx, Db db, AuditService audit) =>
        {
            var cu = Ctx.Require(ctx, "admin");
            using var c = db.Open();
            var synced = 0;
            var skipped = new List<string>();
            foreach (var it in items ?? new List<RoleSyncReq>())
            {
                var id = (it.id ?? "").Trim();
                var name = (it.name ?? "").Trim();
                if (name.Length > 100) name = name.Substring(0, 100);
                var okId = id.Length >= 1 && id.Length <= 30;
                foreach (var ch in id) if (!(char.IsLetterOrDigit(ch) || ch == '_')) okId = false;
                if (!okId || name.Length == 0 || id == "admin" || id == "prod" || id == "sales") { skipped.Add(name.Length > 0 ? name : id); continue; }
                var clash = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppRoles WHERE Name = @n AND Id <> @id", new { n = name, id });
                if (clash > 0) { skipped.Add(name); continue; }
                var exists = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppRoles WHERE Id = @id", new { id });
                if (exists > 0) await c.ExecuteAsync("UPDATE AppRoles SET Name = @n WHERE Id = @id AND Name <> @n", new { n = name, id });
                else
                {
                    await c.ExecuteAsync("INSERT INTO AppRoles (Id, Name, Description) VALUES (@id, @n, N'نقش تعریف‌شده در دسترسی تفصیلی')", new { id, n = name });
                    await audit.LogAsync(cu, "ROLE_CREATE", "AppRoles", id, name);
                }
                synced++;
            }
            return Results.Ok(new { synced, skipped });
        });

        app.MapGet("/api/roles/{id}/permissions", async (string id, Db db) =>
        {
            using var c = db.Open();
            var rows = await c.QueryAsync(
                "SELECT Scope AS scope, TargetKey AS targetKey, Access AS access, RowFilterJson AS rowFilterJson FROM RolePermissions WHERE RoleId = @id ORDER BY Scope, TargetKey",
                new { id });
            return Results.Ok(Conv.ToDicts(rows));
        });

        app.MapPut("/api/roles/{id}/permissions", async (string id, List<PermissionReq> items, HttpContext ctx, Db db, AuditService audit) =>
        {
            var cu = Ctx.Require(ctx, "admin");
            using var c = db.Open();
            await c.OpenAsync();
            using var tx = c.BeginTransaction();
            var roleOk = await c.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppRoles WHERE Id = @id", new { id }, tx);
            if (roleOk == 0) throw new ApiException(404, "نقش پیدا نشد.");
            await c.ExecuteAsync("DELETE FROM RolePermissions WHERE RoleId = @id", new { id }, tx);
            foreach (var it in items)
            {
                if (it.scope is not ("module" or "tab" or "column" or "row")) throw new ApiException(400, "scope باید module/tab/column/row باشد.");
                if (it.access is not ("none" or "read" or "write")) throw new ApiException(400, "access باید none/read/write باشد.");
                if (string.IsNullOrWhiteSpace(it.targetKey)) throw new ApiException(400, "targetKey خالی است.");
                await c.ExecuteAsync(
                    "INSERT INTO RolePermissions (RoleId, Scope, TargetKey, Access, RowFilterJson) VALUES (@r, @s, @k, @a, @f)",
                    new { r = id, s = it.scope, k = it.targetKey, a = it.access, f = it.rowFilterJson }, tx);
            }
            tx.Commit();
            await audit.LogAsync(cu, "ROLE_PERMS", "AppRoles", id, items.Count + " مورد");
            return Results.Ok(new { saved = items.Count });
        });

        // ---------------- گزارش رویدادها (فقط مدیر کل) ----------------
        app.MapGet("/api/audit", async (HttpContext ctx, Db db) =>
        {
            Ctx.Require(ctx, "admin");
            int take = int.TryParse(ctx.Request.Query["take"], out var t) ? Math.Clamp(t, 1, 2000) : 200;
            string? action = ctx.Request.Query["action"];
            using var c = db.Open();
            var rows = await c.QueryAsync(@"
                SELECT TOP (@take) Id AS id, At AS at, UserId AS userId, UserEmail AS userEmail, Action AS action,
                       EntityName AS entityName, EntityId AS entityId, Detail AS detail
                FROM AuditLog WHERE (@a IS NULL OR Action = @a) ORDER BY Id DESC", new { take, a = action });
            return Results.Ok(Conv.ToDicts(rows));
        });
    }
}
