using System.Text.Json;
using Dapper;
using OptimizerApi.Data;
using OptimizerApi.Services;

namespace OptimizerApi.Endpoints;

// API عمومی برای همهٔ جدول‌های داده (ساختار از خود دیتابیس خوانده می‌شود).
//   GET    /api/t                       فهرست جدول‌ها و ستون‌ها
//   GET    /api/t/{table}               خواندن (فیلتر با ?ستون=مقدار ، ?top= ?skip= ?orderBy= ?desc=1)
//   GET    /api/t/{table}/{id}          یک ردیف (جدول‌های تک‌کلیدی)
//   POST   /api/t/{table}               افزودن/به‌روزرسانی یک ردیف (upsert با کلید داخل بدنه)
//   PUT    /api/t/{table}/{id}          افزودن/به‌روزرسانی با کلید در آدرس
//   DELETE /api/t/{table}/{id}          حذف یک ردیف
//   DELETE /api/t/{table}?ستون=مقدار    حذف گروهی با فیلتر (حتماً حداقل یک فیلتر)
//   POST   /api/t/{table}/bulk?mode=replace|append   بارگذاری انبوه (آرایهٔ JSON یا {rows:[...]})
public static class TableEndpoints
{
    // جدول‌هایی که فقط از مسیرهای اختصاصی (کاربران/ورژن‌ها) کار می‌کنند
    private static readonly HashSet<string> Blocked = new(StringComparer.OrdinalIgnoreCase)
    {
        "AppUsers", "AppRoles", "RolePermissions", "AuditLog", "DataVersions",
        "ProdPlanVersionRows", "ProdPlanVersionUnmet", "ProdPlanVersionPayments",
        "SalesPlanVersionRows", "SalesPlanVersionMeta", "ProdActualVersionRows",
        "PlanArchiveVersions", "PlanArchiveRows", "Actuals", "sysdiagrams", "AppStateDocs", "AppStateDocHistory"
    };

    // جدول‌های بخش فروش (نوشتن: مدیر کل و کارشناس فروش) — بقیه: مدیر کل و کارشناس تولید
    private static readonly HashSet<string> Sales = new(StringComparer.OrdinalIgnoreCase)
    {
        "SfProducts", "Channels", "SalesHistory", "MarketHistory", "OwnDistributorSales", "DistributorReports",
        "RealDistributorSales", "MacroInflation", "MacroRegulatoryEvents", "MacroRiskFactors", "SfSettings"
    };

    public static bool CanWrite(CurrentUser u, string table) =>
        u.IsAdmin || (u.Role == "sales" && Sales.Contains(table)) || (u.Role == "prod" && !Sales.Contains(table));

    private static async Task<TableInfo> GetTable(SchemaCache sc, string name)
    {
        var t = await sc.FindAsync(name);
        if (t == null || Blocked.Contains(t.Name))
            throw new ApiException(404, $"جدول «{name}» وجود ندارد یا از این مسیر قابل دسترسی نیست.");
        return t;
    }

    private static TableInfo NeedWrite(TableInfo t, CurrentUser u)
    {
        if (!CanWrite(u, t.Name)) throw new ApiException(403, $"نقش شما اجازهٔ تغییر جدول «{t.Name}» را ندارد.");
        return t;
    }

    private static ColInfo SinglePk(TableInfo t)
    {
        var pk = t.Pk;
        if (pk.Count != 1) throw new ApiException(400, $"جدول «{t.Name}» کلید ترکیبی دارد؛ از POST با کلیدها در بدنه یا فیلتر ?ستون=مقدار استفاده کنید.");
        return pk[0];
    }

    private static (string where, DynamicParameters p) BuildFilter(TableInfo t, IQueryCollection q, string[] reserved)
    {
        var where = new List<string>();
        var p = new DynamicParameters();
        int i = 0;
        foreach (var kv in q)
        {
            if (reserved.Contains(kv.Key, StringComparer.OrdinalIgnoreCase)) continue;
            if (!t.ByLower.TryGetValue(kv.Key.ToLowerInvariant(), out var col))
                throw new ApiException(400, $"ستون «{kv.Key}» در جدول «{t.Name}» وجود ندارد.");
            where.Add($"[{col.Name}] = @f{i}");
            p.Add($"f{i}", Conv.FromString(kv.Value.ToString(), col));
            i++;
        }
        return (where.Count == 0 ? "" : " WHERE " + string.Join(" AND ", where), p);
    }

    public static void Map(WebApplication app)
    {
        app.MapGet("/api/t", async (HttpContext ctx, SchemaCache sc) =>
        {
            var u = Ctx.User(ctx);
            var all = await sc.GetAsync();
            var list = all.Values.Where(t => !Blocked.Contains(t.Name)).OrderBy(t => t.Name).Select(t => new
            {
                table = t.Name,
                keys = t.Pk.Select(k => Conv.CamelName(k.Name)).ToList(),
                canWrite = CanWrite(u, t.Name),
                columns = t.Cols.Select(c => new { name = Conv.CamelName(c.Name), type = c.SqlType, nullable = c.IsNullable, identity = c.IsIdentity }).ToList()
            });
            return Results.Ok(list);
        });

        app.MapGet("/api/t/{table}", async (string table, HttpContext ctx, Db db, SchemaCache sc) =>
        {
            var t = await GetTable(sc, table);
            var q = ctx.Request.Query;
            var (where, p) = BuildFilter(t, q, new[] { "top", "skip", "orderBy", "desc" });

            int top = int.TryParse(q["top"], out var tp) ? Math.Clamp(tp, 1, 500000) : 500000;
            int skip = int.TryParse(q["skip"], out var sk) ? Math.Max(sk, 0) : 0;
            string order;
            string? ob = q["orderBy"];
            if (!string.IsNullOrEmpty(ob))
            {
                if (!t.ByLower.TryGetValue(ob.ToLowerInvariant(), out var oc)) throw new ApiException(400, $"ستون «{ob}» وجود ندارد.");
                order = $"[{oc.Name}]";
            }
            else
            {
                var pk = t.Pk;
                order = pk.Count > 0 ? string.Join(", ", pk.Select(k => $"[{k.Name}]")) : $"[{t.Cols[0].Name}]";
            }
            var desc = (string?)q["desc"] is "1" or "true";
            p.Add("skip", skip);
            p.Add("top", top);
            using var c = db.Open();
            var rows = await c.QueryAsync(
                $"SELECT * FROM [{t.Name}]{where} ORDER BY {order}{(desc ? " DESC" : "")} OFFSET @skip ROWS FETCH NEXT @top ROWS ONLY", p);
            return Results.Ok(Conv.ToDicts(rows));
        });

        app.MapGet("/api/t/{table}/{id}", async (string table, string id, Db db, SchemaCache sc) =>
        {
            var t = await GetTable(sc, table);
            var pk = SinglePk(t);
            using var c = db.Open();
            var rows = await c.QueryAsync($"SELECT * FROM [{t.Name}] WHERE [{pk.Name}] = @id", new { id = Conv.FromString(id, pk) });
            var list = Conv.ToDicts(rows);
            if (list.Count == 0) throw new ApiException(404, "ردیف پیدا نشد.");
            return Results.Ok(list[0]);
        });

        app.MapPost("/api/t/{table}", async (string table, JsonElement body, HttpContext ctx, Db db, SchemaCache sc, AuditService audit) =>
        {
            var u = Ctx.User(ctx);
            var t = NeedWrite(await GetTable(sc, table), u);
            var r = await UpsertAsync(db, t, body, null, u);
            await audit.LogAsync(u, "UPSERT", t.Name, r.id);
            return Results.Ok(new { action = r.action, id = r.id });
        });

        app.MapPut("/api/t/{table}/{id}", async (string table, string id, JsonElement body, HttpContext ctx, Db db, SchemaCache sc, AuditService audit) =>
        {
            var u = Ctx.User(ctx);
            var t = NeedWrite(await GetTable(sc, table), u);
            var r = await UpsertAsync(db, t, body, id, u);
            await audit.LogAsync(u, "UPSERT", t.Name, r.id);
            return Results.Ok(new { action = r.action, id = r.id });
        });

        app.MapDelete("/api/t/{table}/{id}", async (string table, string id, HttpContext ctx, Db db, SchemaCache sc, AuditService audit) =>
        {
            var u = Ctx.User(ctx);
            var t = NeedWrite(await GetTable(sc, table), u);
            var pk = SinglePk(t);
            using var c = db.Open();
            var n = await c.ExecuteAsync($"DELETE FROM [{t.Name}] WHERE [{pk.Name}] = @id", new { id = Conv.FromString(id, pk) });
            if (n == 0) throw new ApiException(404, "ردیف پیدا نشد.");
            await audit.LogAsync(u, "DELETE", t.Name, id);
            return Results.Ok(new { deleted = n });
        });

        app.MapDelete("/api/t/{table}", async (string table, HttpContext ctx, Db db, SchemaCache sc, AuditService audit) =>
        {
            var u = Ctx.User(ctx);
            var t = NeedWrite(await GetTable(sc, table), u);
            var (where, p) = BuildFilter(t, ctx.Request.Query, Array.Empty<string>());
            if (where.Length == 0) throw new ApiException(400, "برای حذف گروهی حداقل یک فیلتر ?ستون=مقدار لازم است (حذف کل جدول از مسیر bulk?mode=replace با آرایهٔ خالی).");
            using var c = db.Open();
            var n = await c.ExecuteAsync($"DELETE FROM [{t.Name}]{where}", p);
            await audit.LogAsync(u, "DELETE_MANY", t.Name, null, ctx.Request.QueryString.Value + " → " + n);
            return Results.Ok(new { deleted = n });
        });

        app.MapPost("/api/t/{table}/bulk", async (string table, JsonElement body, HttpContext ctx, Db db, SchemaCache sc, AuditService audit) =>
        {
            var u = Ctx.User(ctx);
            var t = NeedWrite(await GetTable(sc, table), u);
            string mode = ((string?)ctx.Request.Query["mode"] ?? "append").ToLowerInvariant();
            if (mode != "append" && mode != "replace") throw new ApiException(400, "mode باید append یا replace باشد.");

            JsonElement arr;
            if (body.ValueKind == JsonValueKind.Array) arr = body;
            else if (body.ValueKind == JsonValueKind.Object && body.TryGetProperty("rows", out var rr) && rr.ValueKind == JsonValueKind.Array) arr = rr;
            else throw new ApiException(400, "بدنه باید آرایهٔ ردیف‌ها یا {\"rows\":[...]} باشد.");
            var rows = arr.EnumerateArray().ToList();

            using var c = db.Open();
            await c.OpenAsync();
            using var tx = c.BeginTransaction();
            int deleted = 0;
            if (mode == "replace") deleted = await c.ExecuteAsync($"DELETE FROM [{t.Name}]", null, tx, 300);
            int inserted = await Conv.BulkInsertAsync(c, tx, t, rows);
            tx.Commit();
            await audit.LogAsync(u, "BULK_" + mode.ToUpperInvariant(), t.Name, null, $"inserted={inserted}, deleted={deleted}");
            return Results.Ok(new { inserted, deleted });
        });
    }

    // درج یا به‌روزرسانی یک ردیف
    private static async Task<(string action, string? id)> UpsertAsync(Db db, TableInfo t, JsonElement body, string? idOverride, CurrentUser u)
    {
        if (body.ValueKind != JsonValueKind.Object) throw new ApiException(400, "بدنهٔ درخواست باید یک شیء JSON باشد.");

        var vals = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in body.EnumerateObject())
            if (t.ByLower.TryGetValue(p.Name.ToLowerInvariant(), out var col))
                vals[col.Name] = Conv.FromJson(p.Value, col);

        var pk = t.Pk;
        if (idOverride != null)
        {
            if (pk.Count != 1) throw new ApiException(400, "این جدول کلید ترکیبی دارد؛ از POST استفاده کنید.");
            vals[pk[0].Name] = Conv.FromString(idOverride, pk[0]);
        }

        // پارامتر هر ستون
        var pname = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var prm = new DynamicParameters();
        int i = 0;
        foreach (var kv in vals) { pname[kv.Key] = "p" + i; prm.Add("p" + i, kv.Value); i++; }
        prm.Add("who", u.Email);

        var identityPk = pk.FirstOrDefault(k => k.IsIdentity);
        var nonKeyCols = vals.Keys.Where(k => !pk.Any(x => x.Name.Equals(k, StringComparison.OrdinalIgnoreCase))).ToList();
        var autoSet = new List<string>();
        if (t.Has("UpdatedAt") && !vals.ContainsKey(t.ByLower["updatedat"].Name)) autoSet.Add($"[{t.ByLower["updatedat"].Name}] = SYSUTCDATETIME()");
        if (t.Has("UpdatedBy") && !vals.ContainsKey(t.ByLower["updatedby"].Name)) autoSet.Add($"[{t.ByLower["updatedby"].Name}] = @who");

        using var c = db.Open();

        string KeyText() => string.Join("|", pk.Select(k => vals.TryGetValue(k.Name, out var v) ? Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture) : ""));

        // اگر کلید شناسه‌ای (IDENTITY) داده نشده → فقط درج
        if (identityPk != null && !(vals.TryGetValue(identityPk.Name, out var iv) && iv != null))
        {
            var cols = vals.Keys.Where(k => !t.ByLower[k.ToLowerInvariant()].IsIdentity).ToList();
            var colSql = new List<string>(cols.Select(k => $"[{k}]"));
            var valSql = new List<string>(cols.Select(k => "@" + pname[k]));
            if (t.Has("UpdatedBy") && !vals.ContainsKey(t.ByLower["updatedby"].Name)) { colSql.Add($"[{t.ByLower["updatedby"].Name}]"); valSql.Add("@who"); }
            var sql = colSql.Count == 0
                ? $"INSERT INTO [{t.Name}] DEFAULT VALUES; SELECT CAST(SCOPE_IDENTITY() AS bigint);"
                : $"INSERT INTO [{t.Name}] ({string.Join(",", colSql)}) VALUES ({string.Join(",", valSql)}); SELECT CAST(SCOPE_IDENTITY() AS bigint);";
            var newId = await c.ExecuteScalarAsync<long>(sql, prm);
            return ("insert", newId.ToString());
        }

        if (pk.Count == 0)
        {
            var colSql = vals.Keys.Select(k => $"[{k}]").ToList();
            var valSql = vals.Keys.Select(k => "@" + pname[k]).ToList();
            if (colSql.Count == 0) throw new ApiException(400, "هیچ ستون معتبری در بدنه نبود.");
            await c.ExecuteAsync($"INSERT INTO [{t.Name}] ({string.Join(",", colSql)}) VALUES ({string.Join(",", valSql)})", prm);
            return ("insert", null);
        }

        // همهٔ ستون‌های کلید باید مقدار داشته باشند
        foreach (var k in pk)
            if (!vals.TryGetValue(k.Name, out var kv) || kv == null)
                throw new ApiException(400, $"مقدار کلید «{Conv.CamelName(k.Name)}» لازم است.");

        var whereKey = string.Join(" AND ", pk.Select(k => $"[{k.Name}] = @{pname[k.Name]}"));
        var setList = nonKeyCols.Select(k => $"[{k}] = @{pname[k]}").Concat(autoSet).ToList();

        int n;
        if (setList.Count > 0)
            n = await c.ExecuteAsync($"UPDATE [{t.Name}] SET {string.Join(", ", setList)} WHERE {whereKey}", prm);
        else
            n = await c.ExecuteScalarAsync<int>($"SELECT COUNT(1) FROM [{t.Name}] WHERE {whereKey}", prm);
        if (n > 0) return ("update", KeyText());

        if (identityPk != null) throw new ApiException(404, "ردیف با این شناسه پیدا نشد.");

        var insCols = vals.Keys.Select(k => $"[{k}]").ToList();
        var insVals = vals.Keys.Select(k => "@" + pname[k]).ToList();
        if (t.Has("UpdatedBy") && !vals.ContainsKey(t.ByLower["updatedby"].Name)) { insCols.Add($"[{t.ByLower["updatedby"].Name}]"); insVals.Add("@who"); }
        await c.ExecuteAsync($"INSERT INTO [{t.Name}] ({string.Join(",", insCols)}) VALUES ({string.Join(",", insVals)})", prm);
        return ("insert", KeyText());
    }
}
