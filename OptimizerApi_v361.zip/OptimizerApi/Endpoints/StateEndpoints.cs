using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Dapper;
using OptimizerApi.Data;
using OptimizerApi.Services;

namespace OptimizerApi.Endpoints;

// «سند حالت» — نسخهٔ کاری کل برنامه (state و sfState) روی SQL Server.
// به‌جای حافظهٔ مرورگر، هر کاربر با ورود به برنامه همین سند مشترک را می‌خواند و می‌نویسد.
// جلوگیری از بازنویسی ناخواسته: هر ذخیره باید شمارهٔ نسخهٔ خوانده‌شده (baseVersion) را بفرستد؛
// اگر در این فاصله کسی دیگر ذخیره کرده باشد، پاسخ 409 برمی‌گردد.
//   GET  /api/state/{key}                  خود سند (JSON خام) + هدر X-Doc-Version
//   GET  /api/state/{key}/version          فقط شمارهٔ نسخه (سبک؛ برای بررسی تغییر توسط دیگران)
//   PUT  /api/state/{key}?baseVersion=N    ذخیره (N=0 یعنی سند جدید)
//   GET  /api/state/{key}/history          فهرست نسخه‌های پشتیبان ساعتی (فقط مدیر کل)
//   POST /api/state/{key}/restore/{id}     بازگرداندن از یک پشتیبان (فقط مدیر کل)
public static class StateEndpoints
{
    private static readonly Regex KeyRx = new("^[a-z0-9_]{3,60}$", RegexOptions.Compiled);

    private static string CheckKey(string k) =>
        KeyRx.IsMatch(k) ? k : throw new ApiException(400, "کلید سند نامعتبر است.");

    private class DocRow
    {
        public int Version { get; set; }
        public string Json { get; set; } = "";
        public DateTime UpdatedAt { get; set; }
        public string? UpdatedBy { get; set; }
    }

    private class VerRow
    {
        public int Version { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? UpdatedBy { get; set; }
    }

    public static void Map(WebApplication app)
    {
        app.MapGet("/api/state/{key}", async (string key, HttpContext ctx, Db db) =>
        {
            CheckKey(key);
            using var c = db.Open();
            var row = await c.QuerySingleOrDefaultAsync<DocRow>(
                "SELECT Version, Json, UpdatedAt, UpdatedBy FROM AppStateDocs WHERE DocKey = @k", new { k = key });
            if (row == null) throw new ApiException(404, "هنوز سندی با این کلید ذخیره نشده است.");
            ctx.Response.Headers["X-Doc-Version"] = row.Version.ToString();
            ctx.Response.Headers["X-Doc-Updated-At"] = row.UpdatedAt.ToString("o");
            ctx.Response.Headers["X-Doc-Updated-By"] = Uri.EscapeDataString(row.UpdatedBy ?? "");
            return Results.Text(row.Json, "application/json; charset=utf-8");
        });

        app.MapGet("/api/state/{key}/version", async (string key, Db db) =>
        {
            CheckKey(key);
            using var c = db.Open();
            var row = await c.QuerySingleOrDefaultAsync<VerRow>(
                "SELECT Version, UpdatedAt, UpdatedBy FROM AppStateDocs WHERE DocKey = @k", new { k = key });
            if (row == null) return Results.Ok(new { version = 0, updatedAt = (DateTime?)null, updatedBy = (string?)null });
            return Results.Ok(new { version = row.Version, updatedAt = row.UpdatedAt, updatedBy = row.UpdatedBy });
        });

        app.MapPut("/api/state/{key}", async (string key, HttpContext ctx, Db db, AuditService audit) =>
        {
            // v344 — نقش‌های تعریف‌شده در «دسترسی تفصیلی» (همگام‌شده در AppRoles) هم اجازهٔ ذخیره دارند؛
            // قبلاً فقط admin/prod/sales مجاز بودند و کاربران نقش‌های جدید همیشه «ذخیره نشد» می‌دیدند.
            // محدودیت ویرایش هر صفحه/جدول را خود برنامه بر اساس ماتریس دسترسی اعمال می‌کند.
            var u = Ctx.User(ctx);
            if (u.Role is not ("admin" or "prod" or "sales"))
            {
                using var c0 = db.Open();
                var roleOk = await c0.ExecuteScalarAsync<int>("SELECT COUNT(1) FROM AppRoles WHERE Id = @r", new { r = u.Role });
                if (roleOk == 0) throw new ApiException(403, "شما اجازهٔ این کار را ندارید.");
            }
            CheckKey(key);
            if (!int.TryParse(ctx.Request.Query["baseVersion"], out var baseV) || baseV < 0)
                throw new ApiException(400, "baseVersion لازم است (برای سند جدید 0).");

            string json;
            using (var sr = new StreamReader(ctx.Request.Body, Encoding.UTF8))
                json = await sr.ReadToEndAsync();
            if (json.Length < 2) throw new ApiException(400, "بدنهٔ درخواست خالی است.");
            using (JsonDocument.Parse(json)) { /* فقط اعتبارسنجی ساختار JSON */ }

            using var c = db.Open();
            await c.OpenAsync();
            using var tx = c.BeginTransaction();
            int newV;
            if (baseV == 0)
            {
                var exists = await c.ExecuteScalarAsync<int>(
                    "SELECT COUNT(1) FROM AppStateDocs WITH (UPDLOCK, HOLDLOCK) WHERE DocKey = @k", new { k = key }, tx);
                if (exists > 0) throw new ApiException(409, "این سند قبلاً توسط کاربر دیگری ساخته شده است؛ صفحه را تازه کنید.");
                await c.ExecuteAsync(
                    "INSERT INTO AppStateDocs (DocKey, Version, Json, UpdatedBy) VALUES (@k, 1, @j, @by)",
                    new { k = key, j = json, by = u.Email }, tx, 300);
                newV = 1;
            }
            else
            {
                // پشتیبان ساعتی از نسخهٔ فعلی (قبل از بازنویسی)
                await c.ExecuteAsync(@"
                    IF NOT EXISTS (SELECT 1 FROM AppStateDocHistory WHERE DocKey = @k AND SavedAt > DATEADD(minute, -60, SYSUTCDATETIME()))
                        INSERT INTO AppStateDocHistory (DocKey, Version, Json, SavedBy)
                        SELECT DocKey, Version, Json, UpdatedBy FROM AppStateDocs WHERE DocKey = @k AND Version = @v;",
                    new { k = key, v = baseV }, tx, 300);
                var n = await c.ExecuteAsync(@"
                    UPDATE AppStateDocs SET Json = @j, Version = Version + 1, UpdatedAt = SYSUTCDATETIME(), UpdatedBy = @by
                    WHERE DocKey = @k AND Version = @v",
                    new { k = key, j = json, by = u.Email, v = baseV }, tx, 300);
                if (n == 0) throw new ApiException(409, "کاربر دیگری در این فاصله نسخهٔ جدیدتری ذخیره کرده است.");
                await c.ExecuteAsync(@"
                    DELETE FROM AppStateDocHistory WHERE DocKey = @k AND Id NOT IN
                        (SELECT TOP 100 Id FROM AppStateDocHistory WHERE DocKey = @k ORDER BY Id DESC)",
                    new { k = key }, tx);
                newV = baseV + 1;
            }
            tx.Commit();
            return Results.Ok(new { version = newV });
        });

        app.MapGet("/api/state/{key}/history", async (string key, HttpContext ctx, Db db) =>
        {
            Ctx.Require(ctx, "admin");
            CheckKey(key);
            using var c = db.Open();
            var rows = await c.QueryAsync(
                "SELECT Id AS id, Version AS version, SavedAt AS savedAt, SavedBy AS savedBy, DATALENGTH(Json) AS bytes FROM AppStateDocHistory WHERE DocKey = @k ORDER BY Id DESC",
                new { k = key });
            return Results.Ok(Conv.ToDicts(rows));
        });

        app.MapPost("/api/state/{key}/restore/{id:long}", async (string key, long id, HttpContext ctx, Db db, AuditService audit) =>
        {
            var u = Ctx.Require(ctx, "admin");
            CheckKey(key);
            using var c = db.Open();
            await c.OpenAsync();
            using var tx = c.BeginTransaction();
            var n = await c.ExecuteAsync(@"
                UPDATE d SET d.Json = h.Json, d.Version = d.Version + 1, d.UpdatedAt = SYSUTCDATETIME(), d.UpdatedBy = @by
                FROM AppStateDocs d JOIN AppStateDocHistory h ON h.DocKey = d.DocKey
                WHERE d.DocKey = @k AND h.Id = @id", new { k = key, id, by = u.Email }, tx, 300);
            if (n == 0) throw new ApiException(404, "پشتیبان یا سند پیدا نشد.");
            tx.Commit();
            await audit.LogAsync(u, "RESTORE_STATE", "AppStateDocs", key, "history #" + id);
            return Results.Ok(new { restored = id });
        });
    }
}
