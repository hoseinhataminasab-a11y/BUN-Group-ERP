using Microsoft.Data.SqlClient;

namespace OptimizerApi.Data;

// یک فکتوریِ سادهٔ اتصال — هر endpoint یک IDbConnection تازه از این می‌گیرد (Dapper خودش
// Open/Dispose را مدیریت می‌کند). برای هم‌روندی چند کاربره روی SQL Server مشکلی ندارد؛
// خود SQL Server locking/consistency سطح ردیف را مدیریت می‌کند.
public class Db
{
    private readonly string _connStr;
    public Db(IConfiguration config)
    {
        _connStr = config.GetConnectionString("Optimizer")
            ?? throw new InvalidOperationException("ConnectionStrings:Optimizer در appsettings.json تنظیم نشده.");
    }
    public SqlConnection Open() => new SqlConnection(_connStr);
}
