-- ============================================================
--  Create-NightlyBackupJob.sql
--  ساخت کار (Job) پشتیبان‌گیری شبانهٔ OptimizerDB در SQL Server Agent
--  فقط یک بار، در SSMS روی سرور دیتابیس اجرا شود (با Execute / F5).
--
--  قبل از اجرا فقط این دو خط را در صورت نیاز عوض کنید:
--     @BackupFolder → پوشه‌ای که روی سرور وجود دارد و فضای کافی دارد (با \ در آخر)
--     @KeepDays     → چند روز اخیر نگه داشته شود
--  ساعت اجرا: هر شب ۰۲:۰۰
-- ============================================================
USE msdb;
GO
DECLARE @BackupFolder NVARCHAR(260) = N'D:\Backups\';   -- <<< پوشهٔ پشتیبان
DECLARE @KeepDays     INT           = 14;               -- <<< چند روز نگه داشته شود
DECLARE @JobName      SYSNAME       = N'OptimizerDB - Nightly Backup';

IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = @JobName)
    EXEC msdb.dbo.sp_delete_job @job_name = @JobName;   -- اگر قبلاً ساخته شده بود، دوباره ساخته می‌شود

EXEC msdb.dbo.sp_add_job @job_name = @JobName, @enabled = 1,
     @description = N'Full backup of OptimizerDB every night at 02:00, keeps the last N days.';

-- مرحلهٔ ۱: پشتیبان‌گیری + بررسی سالم بودن فایل
DECLARE @cmd1 NVARCHAR(MAX) = REPLACE(N'
DECLARE @f NVARCHAR(400) = N''<<FOLDER>>OptimizerDB_'' + REPLACE(CONVERT(NVARCHAR(19), GETDATE(), 120), '':'', ''-'') + N''.bak'';
BACKUP DATABASE OptimizerDB TO DISK = @f WITH COMPRESSION, CHECKSUM, INIT;
RESTORE VERIFYONLY FROM DISK = @f WITH CHECKSUM;', N'<<FOLDER>>', @BackupFolder);

EXEC msdb.dbo.sp_add_jobstep @job_name = @JobName, @step_id = 1, @step_name = N'Backup and verify',
     @subsystem = N'TSQL', @database_name = N'master', @command = @cmd1,
     @on_success_action = 3, @on_fail_action = 2;   -- 3 = برو مرحلهٔ بعد ، 2 = شکست

-- مرحلهٔ ۲: پاک کردن پشتیبان‌های قدیمی‌تر از @KeepDays روز
DECLARE @cmd2 NVARCHAR(MAX) = REPLACE(REPLACE(N'
DECLARE @old DATETIME = DATEADD(DAY, -<<DAYS>>, GETDATE());
EXEC master.dbo.xp_delete_file 0, N''<<FOLDER>>'', N''bak'', @old;', N'<<DAYS>>', CAST(@KeepDays AS NVARCHAR(10))), N'<<FOLDER>>', @BackupFolder);

EXEC msdb.dbo.sp_add_jobstep @job_name = @JobName, @step_id = 2, @step_name = N'Delete old backups',
     @subsystem = N'TSQL', @database_name = N'master', @command = @cmd2,
     @on_success_action = 1, @on_fail_action = 1;   -- حتی اگر پاک‌سازی خطا بدهد، پشتیبان امروز معتبر است

-- زمان‌بندی: هر روز ساعت ۰۲:۰۰
EXEC msdb.dbo.sp_add_jobschedule @job_name = @JobName, @name = N'Every night 02:00',
     @freq_type = 4, @freq_interval = 1, @active_start_time = 020000;

EXEC msdb.dbo.sp_add_jobserver @job_name = @JobName;   -- روی همین سرور اجرا شود
GO

-- ---------- امتحان فوری (اختیاری): خط زیر را از حالت توضیح دربیاورید و اجرا کنید ----------
-- EXEC msdb.dbo.sp_start_job N'OptimizerDB - Nightly Backup';
-- چند ثانیه بعد نتیجه را با این دستور ببینید (run_status: 1 = موفق ، 0 = ناموفق):
-- SELECT TOP 5 j.name, h.run_date, h.run_time, h.run_status
-- FROM msdb.dbo.sysjobhistory h JOIN msdb.dbo.sysjobs j ON j.job_id = h.job_id
-- WHERE j.name = N'OptimizerDB - Nightly Backup' AND h.step_id = 0 ORDER BY h.instance_id DESC;
